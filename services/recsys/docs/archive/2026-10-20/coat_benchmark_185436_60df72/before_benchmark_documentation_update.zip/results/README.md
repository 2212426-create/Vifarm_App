# Kết quả RecSys: đọc metadata trước khi trích số

**Chỉ dẫn từng artifact: [CATALOG.md](CATALOG.md).**
Trạng thái triển khai hiện tại ở [CURRENT_STATE](../docs/CURRENT_STATE.md).
Một tên `v4` không xác định loss/backbone/source; thời gian sửa file cũng không
xác nhận kết quả thuộc mô hình hiện hành.

Hai artifact validation ngày 20/10 có phạm vi khác nhau:

| Artifact | Trạng thái |
| :-- | :-- |
| [cdr_paper_method_validation_37b126f2c13fcea9.json](cdr_paper_method_validation_37b126f2c13fcea9.json) | CDR huấn luyện độc lập; ba seed, chỉ validation, chưa tuning/test; có ghi riêng smoke hai dataset |
| [cdr_eq7_validation_6346597634257fd0.json](cdr_eq7_validation_6346597634257fd0.json) | Ablation warm-start đã bị thay thế; cả ba seed chọn MF epoch 0; không đại diện CDR độc lập |

Các `benchmark_*`, `coat_seeds_*`, `tuning_*` khác đang lưu là kết quả lịch sử
so với mốc source hiện hành. Không tự gán ngày chạy cho cả nhóm khi artifact
không ghi ngày; không gọi chúng là kết quả mới chỉ vì cùng tên mô hình.
Port `cdr-author` và lượt `cdr_idcf_tune` là các đường chạy chẩn đoán riêng.

## Giữ nguyên dấu vết

- JSON/Markdown kết quả và evidence giữ nguyên byte; checksum trong
  [docs/catalog.json](../docs/catalog.json).
- Đính chính đặt trong tài liệu hiện hành/catalog, không sửa lại số hoặc metadata cũ.
- Lượt chạy mới dùng artifact khác; không ghi đè đường dẫn cũ hoặc đổi hash cho khớp code mới.
- Kiểm chứng `python docs/check_docs.py`; đọc source/data/config/metric và split
  trước khi trích số từ bất kỳ artifact nào.

`clean --apply` dọn checkpoint, log, bytecode, giữ báo cáo. Nó không tạo lại bằng
chứng của một checkpoint đã xóa. Smoke không dùng thay benchmark chất lượng.
