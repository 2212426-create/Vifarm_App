# Điều tra mô hình: kết luận còn sử dụng được

Trạng thái triển khai và kết quả mới nằm ở [CURRENT_STATE](../CURRENT_STATE.md).
Bản dài trước dọn được giữ tại [archive](../archive/2026-10-20/benchmarks/root_cause_analysis.md)
và bản nguyên byte trong [ZIP](../archive/2026-10-20/documentation_before_cleanup.zip).

## DR-BIAS + CDR

Giữ tiêu đề này để liên kết từ bản chép paper cũ vẫn trỏ đúng. Các điểm dưới đây
là đính chính của dự án; công thức/nội dung bài báo nằm ở PDF và bản chép được bảo toàn.

## Đính chính cho lần đọc sau

- Chênh điểm CDR có cả khác giao thức và các bất nhất loss/filter ở bản cũ.
  Không kết luận “chỉ do dữ liệu” hoặc “chỉ do BCE”.
- Bộ lọc variance ngưỡng 10 từng không loại mẫu trong một lượt cũ. Triển khai hiện
  dùng CV; kết quả cũ đó không mô tả bộ lọc hiện tại.
- Những lượt CDR chọn MF epoch 0 là warm-start ablation, không phải thành tích
  của CDR nguyên bản. Benchmark/tuning/seed runner hiện không nạp checkpoint MF.
- CDR paper cho phép nhiều hàm error. Bản hiện hành chọn BCE; không suy ra rằng
  mọi CDR bắt buộc dùng BCE hoặc mọi MF phải đổi sang BCE.
- IViDR-staged cũ có `alpha_residual=1` trả lại treatment gốc; đổi thành 0 vẫn
  không bổ sung được các MLP/reconstruction/BCE còn thiếu của IViDR paper.
- Port `cdr-author` không tương đương bitwise mã công bố và dùng một phần nhãn
  tập chấm điểm để ước lượng propensity. Không dùng số đó để chứng nhận tái lập.

## Sau sửa pipeline Coat — 20/10/2026

Các lỗi đã xử lý: iVAE Coat dùng kiến trúc 16/32/3 và patience 100; chọn checkpoint
và early stopping sau full-beta warm-up. Ngân sách smoke quá ngắn được đánh dấu
riêng. Trainer CDR cập nhật recommendation rồi tính lại sai số để cập nhật
imputation, thay cho cập nhật hai bên từ cùng logits cũ.

CDR Coat mặc định dùng Naive Bayes trên validation, không dùng nhãn test cho
hiệu chỉnh. Trọng số IPS lớn nhất giảm từ 245.07 xuống 14.33; top 1% mẫu chiếm
1.32% tổng trọng số imputation thay vì 50.12%. Đây là thay đổi estimator
propensity có công bố nguồn, không phải cap trọng số hoặc sửa Eq. (7).

Một phần miền tuning paper đã được kiểm tra trên validation. Cấu hình chốt:
LR .1, wd .0001, batch 512, eta .1, dim 4, patience 20; chọn theo mean validation
ba seed 42/43/44 giữa hai cấu hình vào vòng xác nhận. Chưa chạy đủ 1120 tổ hợp.
CDR validation lần lượt .498562/.497547/.491869, mean .495993; vẫn chưa vượt MF.
Các seed này tham gia chọn cấu hình nên không phải kiểm chứng độc lập ngoài mẫu.

[Validation bản chốt](../../results/coat_pipeline_fix_validation_20261020.json),
[các trial phát triển](../../results/coat_pipeline_fix_search_20261020.json) và
[trạng thái hiện hành](../CURRENT_STATE.md) giữ số và source tương ứng. Chưa có
benchmark test đầy đủ của bản sửa. Không chuyển số test cũ sang source mới.

## Báo cáo Coat đầy đủ trước sửa — 20/10/2026

**Phần dưới mô tả source `36230d1cd908`, trước bản sửa ở trên.** Những cấu hình
và câu “chưa sửa runtime” trong phần điều tra này là trạng thái tại mốc đó.

[Báo cáo người dùng chạy](../../results/benchmark_coat_all_429e263db0_v4.md),
[JSON gốc](../../results/benchmark_coat_all_429e263db0_v4.json) và
[evidence chỉ đọc](../../results/coat_report_analysis_20261020.json).
Đây là full-data seed 42, không phải smoke; source `36230d1cd908`, chưa tuning.

| Mô hình | Test NDCG@5 dự án | Mốc paper để tham khảo | Cách diễn giải |
| :-- | --: | :-- | :-- |
| MF | .547612 | .5524 ± .0144 trong paper iDCF | Chênh .004788; cùng thang biến thiên seed được paper báo cáo, chưa phải kiểm định tái lập |
| iDCF | .463745 | .5744 ± .0122 trong paper iDCF | Giảm đáng kể; chưa dùng kiến trúc iVAE Coat đã tune công khai |
| DR-BIAS + CDR | .376982 | .6567 trong paper CDR | Khác cả thực nghiệm và cấu hình tối ưu; không coi chênh số thô là mức suy giảm cùng điều kiện |

Mốc paper từ [iDCF Table 2 và Appendix B](https://arxiv.org/pdf/2302.05052)
và [CDR Table 2, §4.1](https://jiawei-chen.github.io/paper/CIKM23-CDR.pdf).
Một seed dự án không thay thế trung bình 10 seed của iDCF. Giao thức chung bám
iDCF; khác biệt nhỏ evaluator không đủ bằng chứng để giải thích toàn bộ chênh lệch.

### iDCF: cấu hình ví dụ khác mô hình Coat đã tune

Local dùng iVAE latent 32 / hidden 64 / 2 lớp theo `sample_config`. Tác giả xuất
latent qua [notebook](https://github.com/BgmLover/iDCF/blob/main/save_ae_params.ipynb)
bằng cách nạp [checkpoint đã tune](https://github.com/BgmLover/iDCF/blob/main/tuned_models/coat_val_ivae_exposure_best.pt).
Kiểm tra trực tiếp checkpoint SHA256 `a37531edb98cdfa1cb0b47505f14d42388fd2e006416705ee7493046bcc4edd8`:
encoder `fc_0.weight` có shape (32,314), `fc_1.weight` (32,32), `fc_2.weight`
(16,32), tức hidden 32 / latent 16 / 3 lớp tuyến tính. Vì vậy nhận định dùng cấu
hình ví dụ là đủ để tái lập Coat cần được rút lại. Tensor không cho biết toàn bộ
siêu tham số huấn luyện; đổi riêng dim chưa chứng minh sẽ khôi phục điểm paper.

Local có 232 user train iVAE, batch 512 nên một update/epoch. Với trần 2000 epoch,
KL warm-up dài 400 update. iVAE chọn epoch 51 (beta lúc train .125), dừng epoch
56 (beta .1375), trong khi validation tính ELBO với beta 1. Stage 2 chọn epoch
3 và dừng 8. Đây là checkpoint được chọn trước khi kết thúc warm-up, cần kiểm
tra ảnh hưởng của schedule/patience trên validation. Chưa có ablation chứng minh
đây là nguyên nhân duy nhất. Chỉ tăng trần epoch, giữ early stopping, không giải
quyết việc dừng sớm này. Mã tác giả còn khác cách đếm update anneal và lấy mẫu
validation, nên không gọi hai quá trình huấn luyện là tương đương.

### CDR: có khác giao thức và dấu hiệu tối ưu kém

Paper mô tả rating > 3 và validation/test 10/90. Script Coat công bố lại dùng
rating >= 3, toàn bộ random log để chấm điểm, quy ước user không positive khác
và ước lượng propensity Naive Bayes từ một phần nhãn random. Dự án dùng rating
>= 4, split user 30/70, loại user không positive và propensity file Coat. Không
đồng nhất script với paper hoặc đổi threshold chỉ để điểm cao hơn.

Triển khai hiện dùng Eq. (7), CV filter và dropout embedding theo paper; script
tác giả có các khác biệt estimator/filter/dropout đã ghi ở
[paper_model_alignment](paper_model_alignment.md). LR .05, dim 4, batch 128 lấy
từ script không mặc nhiên tối ưu sau những thay đổi này. Grid chưa được chạy.

Tuy vậy, khác giao thức không giải thích hết chất lượng nội bộ hiện tại:

- CDR chọn epoch 6, Val NDCG .425608, Test AUC .560873; Popularity NDCG .351106.
  So với Popularity, CDR tăng .025875, Wilcoxon p=.514 trên user của seed này;
  chưa có bằng chứng cải thiện ranking rõ ràng. Đây không phải std giữa seed.
- Risk recommendation quanh .69; imputation loss dao động mạnh (epoch 2–5:
  khoảng 29.8–75.1). Risk tổng hợp không chứng minh mọi dự đoán bằng .5.
- Trên 6960 cặp train, inverse propensity lớn nhất 245.07; IPS ESS khoảng 2211.
  Loss imputation dùng trọng số `w^3 * (1 - 1/w)^2`, lớn nhất khoảng 14.6 triệu;
  70 mẫu có trọng số cao nhất (xấp xỉ 1%) chiếm 50.12% tổng trọng số imputation.
  Đây là khối lượng trọng số, không phải khối lượng gradient; cần kiểm tra residual
  và gradient mới kết luận mất ổn định. Không tự cap trọng số rồi gọi là CDR gốc.
- Bộ lọc CV ở epoch được chọn loại khoảng 5.01% observed và 5.18% direct imputation.
  Không áp dụng lại nhận định cũ “bộ lọc không hoạt động” cho bản này.

Audit cũ từng chấm lại cùng một checkpoint port với quy tắc khác và thấy điểm đổi
mạnh. Điều đó chứng minh metric phụ thuộc protocol, không định lượng phần chênh
do protocol trong checkpoint CDR hiện tại. Không lấy checkpoint port làm benchmark
độc lập vì có dùng nhãn tập chấm điểm cho propensity.

### Thứ tự xử lý cần thiết

1. Xác minh ánh xạ dữ liệu/feature và latent với pipeline iVAE Coat đã tune; tách
   kiểm chứng kiến trúc khỏi kiểm chứng schedule và early stopping trên validation.
2. Với CDR, chốt chạy tái lập công thức paper hay tái lập script có ghi rõ khác
   biệt; kiểm tra định nghĩa/ước lượng propensity và độ tập trung gradient trước
   khi tune LR, weight decay, eta, batch bằng validation. Giữ MF-MSE và CDR-BCE độc lập.
3. Khóa cấu hình, báo mean/std nhiều seed rồi chấm test ở lượt mới. Không chọn
   cấu hình theo test vừa đọc hoặc tuyên bố test công thức đạt là mô hình đã tốt.

Đợt phân tích này không sửa runtime, không tune hoặc chạy lại mô hình. Các nguyên
nhân chưa được kiểm tra bằng thí nghiệm đối chứng vẫn được giữ là giả thuyết.

## Bằng chứng lịch sử

[CDR audit evidence](cdr_audit_2026-10-19_evidence.json) và
[review evidence](review_2026-10-19_evidence.json) giữ nguyên số đo và hash cũ.
Công thức/phép đo trong archive mô tả phiên bản tại thời điểm điều tra;
đường dẫn tới source ngày nay không có nghĩa lỗi đó vẫn còn.

Kết quả được phép trích và phần việc còn thiếu: [catalog kết quả](../../results/CATALOG.md),
[đối chiếu mô hình](paper_model_alignment.md), [CURRENT_STATE](../CURRENT_STATE.md).
