# Trạng thái RecSys hiện hành

Mốc rà soát: **20/10/2026**, sau khi bỏ MF-MSE → CDR-BCE warm-start.
Đây là điểm đọc đầu tiên về triển khai và bằng chứng của dự án.
Chi tiết máy đọc được nằm ở [state_snapshot.json](state_snapshot.json).

## Căn cứ và phạm vi

Logic thực thi/config quyết định mô hình đang chạy; metadata và JSON của từng lượt
quyết định số đo thuộc phiên bản nào. Tài liệu paper mô tả nghiên cứu bên ngoài.
Đề cương, slide và báo cáo cũ không quyết định trạng thái triển khai hiện tại.

Source hash của mốc đã kiểm chứng:
`36230d1cd908e7d9d2696a8d2936930fa8950c8549f27849f75e35ae82c0fca2`.
Hash tính theo `src/` và `experiments/`, theo hàm
[`source_signature`](../src/utils/artifacts.py). Đây là dấu vết của lượt chạy,
không phải lời hứa rằng source về sau vẫn giữ nguyên.

## Mô hình đang sử dụng

| Mô hình | Hành vi thực thi | Giới hạn cần giữ khi mô tả |
| :-- | :-- | :-- |
| MF | MSE trên score thô; có user/item bias, intercept cố định 0; Adam, Uniform(-.01,.01), decay mọi tham số, không scheduler | Theo mô hình MF của mã iDCF; điểm lịch sử Normal/BCE không đại diện bản hiện tại |
| iDCF | iVAE trên exposure/proxy rồi MF + thành phần latent; feedback MSE; training 10 mẫu, inference dùng mean | Có thay đổi địa phương ở chọn checkpoint iVAE và xử lý dữ liệu; chưa xác nhận tái lập điểm paper |
| DR-BIAS + CDR | BCE, Eq. (7), MF dot-product không bias; CV filter, MC 10 mẫu; huấn luyện từ đầu, LR cố định, không cap inverse propensity | Tên profile `paper` chỉ nói về lựa chọn thuật toán; dữ liệu/propensity/giao thức chưa khớp toàn bộ paper |
| IViDR-approx | Bản xấp xỉ theo giai đoạn, chỉ chạy khi yêu cầu tường minh | Chưa có MLP0/1/2, reconstruction và BCE đúng paper; không thuộc `all` hoặc bộ nhiều seed mặc định |

Nguồn mặc định: [MF/CDR config](../src/training/config.py),
[iDCF pipeline config](../src/causal/idcf/train_idcf.py).
Các giá trị mặc định là điểm xuất phát; có grid không đồng nghĩa đã chạy xong tuning.
MF có 10 và CDR có 1.120 tổ hợp trong grid; không tuyên bố cấu hình tối ưu khi chưa có artifact.
[Đối chiếu phương pháp và lựa chọn triển khai](benchmarks/paper_model_alignment.md).

## Giao thức thực nghiệm và phục vụ

Benchmark dự án dùng biased train; Coat positive rating >= 4, KuaiRand dùng click.
Random log chia theo user 30% validation / 70% test, seed 1234. Ranking chỉ trên
logged candidates, NDCG@5/Recall@5 macro loại user không có positive; Recall chia
toàn bộ positive. Ranking gộp cặp lặp bằng any-positive; train CDR gộp mean label.
Coat giữ và công bố overlap train/random. [Công thức và ngoại lệ](benchmarks/evaluation_protocol.md).

CDR paper mô tả validation/test 10/90; script Coat công bố lại có quy ước khác paper.
Không đặt điểm của các giao thức này cạnh điểm dự án để kết luận hơn/kém.
Propensity benchmark Coat lấy từ file dữ liệu; KuaiRand và API dùng proxy tần suất item.
CDR KuaiRand/API vì vậy chưa phải cấu hình tái lập đầy đủ của thực nghiệm công bố.

API TopTop phục vụ MF-MSE và CDR-BCE độc lập trên tương tác ứng dụng, có ngân sách
và siêu tham số riêng. Không phục vụ IViDR; yêu cầu không hỗ trợ có fallback_reason.
Một số docstring cũ trong source vẫn gọi MF API là BCE: kiểm tra `_train_mf`, không
dùng comment đó để suy ra objective. [Hướng dẫn API](api/colab_api_guide.md).

`cdr-author` và `cdr-tune` là các port/chẩn đoán riêng, có khác biệt với source
tác giả (bao gồm khởi tạo imputation trong port); không gắn nhãn tương đương bitwise.
`cdr-author` còn dùng nhãn từ tập chấm điểm để ước lượng propensity, nên không phải
held-out benchmark độc lập theo giao thức hiện hành.

## Bằng chứng đã có

| Bằng chứng | Kết quả | Phạm vi kết luận |
| :-- | :-- | :-- |
| Suite kiểm thử ở mốc source trên | 97 test: 96 đạt, 1 CUDA test bỏ qua | Kiểm tra công thức, gradient, data, workflow, API và checkpoint trên CPU; không chứng minh chất lượng ranking |
| Smoke MF/iDCF/CDR trên Coat và KuaiRand 64 user | Thành công | Kiểm tra vận hành; không dùng điểm smoke làm benchmark |
| CDR huấn luyện độc lập, Coat seed 42/43/44 | Epoch chọn 6/7/17; Val NDCG@5 .425608/.417528/.453052 | Cấu hình cố định chưa tuning, chỉ validation; chưa có kết luận test hay vượt MF/paper |
| Benchmark đầy đủ Coat, seed 42, ngày 20/10 | Test NDCG@5 MF .547612, iDCF .463745, CDR .376982 | Ba mô hình mặc định, chọn epoch bằng validation; một seed, chưa tuning và chưa đánh giá biến thiên seed |

Artifact trực tiếp: [CDR independent validation](../results/cdr_paper_method_validation_37b126f2c13fcea9.json).
Trường `evaluation=validation_only_no_held_out_test` áp dụng cho ba lượt CDR trong
`runs`; trường `smoke` ghi riêng kiểm tra vận hành của hai dataset.

Lượt benchmark đầy đủ mới nằm ở
[báo cáo Coat](../results/coat_full_20261020_185436_60df72/benchmark_coat_all_429e263db0_v4.md),
[JSON chi tiết](../results/coat_full_20261020_185436_60df72/benchmark_coat_all_429e263db0_v4.json)
và [biên bản hoàn tất](../results/coat_full_20261020_185436_60df72/completion.json).
MF/iDCF/CDR lần lượt chọn epoch 23/3/6; iVAE của iDCF chạy 56 epoch và chọn epoch 51.
Trần feedback 100 epoch, iVAE 2000 epoch, có early stopping; không ép mọi mô hình
chạy đủ trần khi validation đã dừng cải thiện. Trong lượt này MF có điểm test cao
nhất; không khái quát thành kết luận nhiều seed hoặc kết quả tái lập paper.

Lượt đầy đủ dùng `venv` workspace: Python 3.12.10, NumPy 2.5.4, PyTorch 2.14.1+cpu,
pandas 3.0.6, CPU 2 thread; source/data hash khớp mốc đang ghi. Bộ kiểm thử 97 test
và ba lượt CDR validation ở trên vẫn thuộc môi trường kiểm chứng trước đó.

Kiểm chứng trên Python 3.12, NumPy 2.5.2, PyTorch 2.14.1+cpu, pandas 3.0.6 ở môi
trường thử nghiệm riêng. `venv` trong workspace từng bị Windows Application Control
chặn DLL NumPy; không suy ra mọi môi trường đều chạy được hoặc test CUDA đã đạt.
Số test trên là kết quả tại mốc đã ghi, không phải test mới được chạy trong mỗi lần đọc.

## Những kết luận không được chuyển sang phiên bản hiện tại

- [Warm-start validation cũ](../results/cdr_eq7_validation_6346597634257fd0.json):
  cả ba seed chọn MF epoch 0, nên không phải bằng chứng CDR fine-tune tốt hơn.
- Các `benchmark_*`, `coat_seeds_*`, `tuning_*` đang lưu có metadata/kiến trúc cũ;
  đọc [catalog kết quả](../results/CATALOG.md) trước khi trích số. Không đổi nhãn phiên bản.
- CDR .6567 (Coat DR-BIAS+CDR), .3098 (KuaiRand DR-BIAS+CDR) và .3167
  (KuaiRand MRDR+CDR) là các số paper khác dataset/biến thể, không phải số dự án.
- Không có bằng chứng hiện hành cho “CDR/IViDR vượt trội mọi chỉ số”, “loại bỏ
  hoàn toàn confounding”, hoặc độ trễ API 150–250 ms. Những câu này có trong slide
  cũ đã thu hồi khỏi tài liệu dùng hiện tại.

## Công việc còn thiếu

1. Tuning bằng validation, khóa cấu hình và chạy benchmark nhiều seed mới trước
   khi kết luận chất lượng MF/iDCF/CDR hiện tại trên test.
2. Đối chiếu dữ liệu và propensity KuaiRand; nếu tái lập từng paper thì tách đúng
   protocol, không sửa nhãn một benchmark dùng giao thức chung.
3. Triển khai đúng các thành phần còn thiếu của IViDR trước khi đưa vào bộ mặc định.
4. Có benchmark riêng trên dữ liệu TopTop và phép đo độ trễ nếu muốn tuyên bố chất lượng phục vụ.

## Quy tắc cập nhật

Hướng dẫn hiện hành chỉ giữ một kết luận cho mỗi mốc. Khi trạng thái đổi, lưu
bản trước vào archive, cập nhật tài liệu này và snapshot bằng bằng chứng phù hợp.
Artifact, paper và snapshot cũ giữ nguyên; đính chính được ghi ở tài liệu mới.
Không sửa một source/data hash cũ cho khớp source mới. Chạy
`python docs/check_docs.py` để kiểm tra phân loại, liên kết và checksum.
[Mục lục](README.md) · [Lưu trữ và bản gốc trước dọn](archive/README.md).
