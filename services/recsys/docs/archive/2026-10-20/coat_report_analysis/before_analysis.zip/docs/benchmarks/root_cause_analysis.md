# Điều tra mô hình: kết luận còn sử dụng được

Trạng thái triển khai và kết quả mới nằm ở [CURRENT_STATE](../CURRENT_STATE.md).
Bản dài trước dọn được giữ tại [archive](../archive/2026-10-20/benchmarks/root_cause_analysis.md)
và bản nguyên byte trong [ZIP](../archive/2026-10-20/documentation_before_cleanup.zip).

## DR-BIAS + CDR

Giữ tiêu đề này để liên kết từ bản chép paper cũ vẫn trỏ đúng. Các điểm dưới đây
là đính chính của dự án; công thức/nội dung bài báo nằm ở PDF và bản chép được bảo toàn.

## Đính chính cho lần đọc sau

- Chênh điểm CDR có cả khác giao thức và các bất nhất loss/filter ở bản cũ.
  Không kết luận “chỉ do dữ liệu” hoặc “chỉ do BCE”.
- Bộ lọc variance ngưỡng 10 từng không loại mẫu trong một lượt cũ. Triển khai hiện
  dùng CV; kết quả cũ đó không mô tả bộ lọc hiện tại.
- Những lượt CDR chọn MF epoch 0 là warm-start ablation, không phải thành tích
  của CDR nguyên bản. Benchmark/tuning/seed runner hiện không nạp checkpoint MF.
- CDR paper cho phép nhiều hàm error. Bản hiện hành chọn BCE; không suy ra rằng
  mọi CDR bắt buộc dùng BCE hoặc mọi MF phải đổi sang BCE.
- IViDR-staged cũ có `alpha_residual=1` trả lại treatment gốc; đổi thành 0 vẫn
  không bổ sung được các MLP/reconstruction/BCE còn thiếu của IViDR paper.
- Port `cdr-author` không tương đương bitwise mã công bố và dùng một phần nhãn
  tập chấm điểm để ước lượng propensity. Không dùng số đó để chứng nhận tái lập.

## Bằng chứng lịch sử

[CDR audit evidence](cdr_audit_2026-10-19_evidence.json) và
[review evidence](review_2026-10-19_evidence.json) giữ nguyên số đo và hash cũ.
Công thức/phép đo trong archive mô tả phiên bản tại thời điểm điều tra;
đường dẫn tới source ngày nay không có nghĩa lỗi đó vẫn còn.

Kết quả được phép trích và phần việc còn thiếu: [catalog kết quả](../../results/CATALOG.md),
[đối chiếu mô hình](paper_model_alignment.md), [CURRENT_STATE](../CURRENT_STATE.md).
