# RecSys: MF, iDCF và DR-BIAS + CDR

[Trạng thái hiện hành](docs/CURRENT_STATE.md) · [Mục lục](docs/README.md) ·
[Catalog kết quả](results/CATALOG.md).
Hỗ trợ cả ba mô hình trên **Coat, Yahoo! R3, KuaiRand-Pure**.
CDR mặc định trên Coat/Yahoo dùng thuật toán từ source tác giả khóa commit;
MF/iDCF giữ MSE và CDR giữ BCE, huấn luyện độc lập.

## Chuẩn bị và dữ liệu

Chạy từ `services/recsys`. Môi trường venv hiện tại đã được kiểm chứng trên CPU.
Nếu cài mới:

```powershell
py -3.12 -m venv venv
.\venv\Scripts\python.exe -m pip install -r requirements.txt
```

Coat cần `train.ascii`, `test.ascii`, `propensities.ascii` và thư mục
`user_item_features/` ở `data/raw/coat/`.
KuaiRand cần hai standard log, random log và `user_features_pure.csv` trong
`data/raw/kuairand_pure/data/` hoặc `kuairand_pure/`.
Loader ưu tiên `./data/`, rồi `../data/`; data_dir tường minh không tự fallback.

Yahoo đã tải đầy đủ vào `data/raw/yahoo/`. Để tải lại trên máy khác:

```powershell
.\venv\Scripts\python.exe experiments\run.py download-yahoo
```

Lệnh lấy đúng 6 file từ commit
`6b4e6cca3df23b8d85b38fdc2e7eb5c812861ea9`, kiểm tra SHA-256 và giữ README
Yahoo Webscope cùng điều kiện sử dụng đi kèm. Raw data không đưa vào Git.
Dữ liệu: 15.400 user, 1.000 item, 311.704 biased / 54.000 random ratings.
iDCF Yahoo dùng survey thật; nhóm thiếu survey có category thiếu. Đây là mở
rộng dataset của dự án, chưa phải kết quả Yahoo từ paper iDCF.

## Chạy thử và chạy đầy đủ

Kiểm tra nhanh ba mô hình trên Yahoo, subset 64 user, 1 epoch feedback / 2 epoch iVAE:

```powershell
.\venv\Scripts\python.exe experiments\run.py smoke --dataset yahoo
```

Chạy đầy đủ ba mô hình trên Yahoo, giữ ngân sách mặc định và chọn checkpoint bằng validation:

```powershell
.\venv\Scripts\python.exe experiments\run.py benchmark --dataset yahoo --model all --device cpu --threads 2
```

Chạy đầy đủ ba mô hình trên Coat:

```powershell
.\venv\Scripts\python.exe experiments\run.py benchmark --dataset coat --model all --device cpu --threads 2
```

Đổi `--dataset all` để chạy cả Coat, Yahoo và KuaiRand.
Đổi `--model mf|idcf|cdr` để chạy riêng (chọn một giá trị).
Mỗi lượt benchmark tạo JSON/Markdown riêng trong `results/`, checkpoint riêng
trong `checkpoints/benchmark_runs/`. iVAE mặc định có trần 2000 epoch và chọn
checkpoint sau full-beta warm-up, nên có thể cần nhiều thời gian.

Thử toàn dữ liệu Yahoo với ngân sách ngắn:
`benchmark --dataset yahoo --model all --quick --epochs 1 --ivae-epochs 2 --device cpu --threads 2`.
Điểm smoke/quick không dùng để so chất lượng với paper.

## Đối chiếu CDR với script công bố

```powershell
.\venv\Scripts\python.exe experiments\run.py cdr-source --dataset coat --threads 2
.\venv\Scripts\python.exe experiments\run.py cdr-source --dataset yahoo --threads 2
```

Lệnh này giữ điều kiện script: >=3, 5% nhãn random chấm điểm dùng cho propensity,
toàn bộ random log, zero-positive nhận 1, Recall bounded và dừng theo train loss.
Kết quả Coat kiểm chứng: NDCG .656665 / Recall bounded .667816.
**Đây là đối chứng script; không thay thế benchmark held-out.**
Benchmark chung dùng >=4, user split 30/70 và calibration chỉ validation.
Xem [định nghĩa và khác biệt paper/source](docs/benchmarks/paper_model_alignment.md).

## Các lệnh khác

| Lệnh sau `experiments/run.py` | Phạm vi |
| :-- | :-- |
| `test` | Suite kiểm thử |
| `smoke` | Cả ba mô hình; Coat đầy đủ, Yahoo/KuaiRand 64 user |
| `evaluate --dataset yahoo --checkpoint FILE` | Chấm checkpoint tương thích, không huấn luyện lại |
| `coat-seeds` | MF/iDCF/CDR released, seed 42–51; có `--cdr-implementation equation` |
| `benchmark ... --cdr-implementation equation` | Chạy biến thể Eq. (7)/CV cũ; mặc định KuaiRand |
| `benchmark --dataset coat --model cdr --cdr-implementation equation --cdr-propensity provided_coat` | Đối chứng propensity file Coat của bản Eq. (7) |
| `tune --model mf` / `tune-kr --model mf` | Tuning MF trên Coat / KuaiRand |
| `tune --model cdr` / `tune-kr --model cdr` | Grid 1.120 cấu hình của bản Eq. (7), không phải released; chưa có CLI tune Yahoo |
| `mf --dataset yahoo` | MF riêng |
| `optimizers` | Thí nghiệm Adam/SGD riêng |
| `cdr-author` / `cdr-tune` | Các port chẩn đoán cũ, không phải lệnh cdr-source mới |
| `protocol` | In giao thức đánh giá |
| `clean` / `clean --apply` | Xem trước / dọn checkpoint, log, bytecode; giữ raw data và báo cáo |

Mỗi lệnh có `--help`. IViDR-approx chỉ chạy tường minh trên Coat/KuaiRand;
chưa đúng toàn bộ paper, không thuộc bộ mặc định.

## Kiểm chứng và API

```powershell
.\venv\Scripts\python.exe experiments\run.py test
.\venv\Scripts\python.exe docs\check_docs.py
.\venv\Scripts\python.exe -m uvicorn src.api.app:app --port 8000
```

[Giao thức chung](docs/benchmarks/evaluation_protocol.md) ·
[Config MF/CDR](src/training/config.py) · [Config iDCF](src/causal/idcf/train_idcf.py).
API TopTop giữ cấu hình phục vụ riêng, user mới dùng popularity.
[Hướng dẫn API/Colab](docs/api/colab_api_guide.md).
