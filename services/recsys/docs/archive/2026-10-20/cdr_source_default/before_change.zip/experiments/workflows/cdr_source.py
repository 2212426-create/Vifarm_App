"""Run the published CDR script conditions, separately from held-out benchmarks.

This explicitly uses 5% of the random evaluation labels for Naive Bayes, as the
published script does. Results must not be substituted for shared test scores.
"""
import argparse
from datetime import datetime
import json
from pathlib import Path
from uuid import uuid4

import numpy as np
import torch
from scipy.stats import rankdata

from src.causal.cdr.released import ReleasedCDR,fit_released,released_inverse_propensity,UPSTREAM_COMMIT,UPSTREAM_URL
from src.data_pipeline.coat_dataset import load_coat_raw_features
from src.data_pipeline.yahoo_dataset import load_yahoo_raw
from src.training.config import released_cdr_config
from src.utils.helpers import set_seed,RESULTS_DIR,CHECKPOINT_DIR
from src.utils.artifacts import source_signature


def source_metrics(model,x,y,k=5):
    with torch.no_grad():
        pred=model(torch.as_tensor(x[:,0]).long(),torch.as_tensor(x[:,1]).long()).sigmoid().numpy()
    ndcg,recall=[],[]
    for user in np.unique(x[:,0]):
        mask=x[:,0]==user
        labels,scores=y[mask],pred[mask]
        top=np.argsort(-scores)[:k]
        discount=1/np.log2(np.arange(2,len(top)+2))
        ideal=np.sort(labels)[::-1][:k]
        denominator=float((ideal*discount).sum())
        ndcg.append(float((labels[top]*discount).sum()/denominator) if denominator else 1.)
        recall.append(float(labels[top].sum()/ideal.sum()) if ideal.sum() else 1.)
    positive = np.asarray(y) > 0
    n_positive, n_negative = int(positive.sum()), int((~positive).sum())
    auc = ((rankdata(pred)[positive].sum() - n_positive * (n_positive + 1) / 2)
           / (n_positive * n_negative)) if n_positive and n_negative else None
    return {"NDCG@5":float(np.mean(ndcg)),"Recall@5_bounded":float(np.mean(recall)),
            "AUC_global":None if auc is None else float(auc),"users":len(ndcg)}


def run_source(dataset,epochs=1000,seed=2020,threads=2,output_dir=None):
    if dataset not in ("coat","yahoo") or epochs<1 or threads<1: raise ValueError("Invalid source run options")
    torch.set_num_threads(threads)
    set_seed(seed)
    if dataset=="coat":
        raw=load_coat_raw_features()
        u,i=np.nonzero(raw["train_matrix"]);x=np.stack([u,i],1);y=raw["train_matrix"][u,i].astype(int)
        u,i=np.nonzero(raw["test_matrix"]);xt=np.stack([u,i],1);yt=raw["test_matrix"][u,i].astype(int)
        n_users,n_items=raw["train_matrix"].shape
    else:
        raw=load_yahoo_raw()
        x,y=raw["train_ratings"][:,:2],raw["train_ratings"][:,2].copy()
        xt,yt=raw["random_ratings"][:,:2],raw["random_ratings"][:,2].copy()
        # Preserve source one-based IDs and its dummy zero row/column.
        n_users,n_items=int(x[:,0].max()+1),int(x[:,1].max()+1)
        order=np.arange(len(x));np.random.shuffle(order);x,y=x[order],y[order]
    y,yt=(y>=3).astype(int),(yt>=3).astype(int)
    cfg=released_cdr_config(dataset,epochs=epochs)
    model=ReleasedCDR(n_users,n_items,cfg["embedding_dim"],cfg["un_thres"],cfg["dropout_rate"])
    order=np.arange(len(yt));np.random.shuffle(order);selected=order[:int(.05*len(order))]
    inverse,calibration=released_inverse_propensity(x,y,yt[selected])
    history=fit_released(model,x,y,inverse,epochs=epochs,batch_size=cfg["batch_size"],lr=cfg["lr"],
                         weight_decay=cfg["weight_decay"],G=cfg["G"])
    metrics=source_metrics(model,xt,yt)
    run_id=datetime.now().strftime("%Y%m%d_%H%M%S")+"_"+uuid4().hex[:8]
    cp=Path(CHECKPOINT_DIR)/"cdr_source"/run_id
    cp.mkdir(parents=True,exist_ok=False)
    checkpoint=cp/f"{dataset}.pt"
    torch.save(dict(model_state_dict=model.state_dict(),config=cfg,dataset=dataset,upstream_commit=UPSTREAM_COMMIT),checkpoint)
    result=dict(identity=dict(code_sha256=source_signature(),upstream=UPSTREAM_URL,seed=seed,dataset=dataset),
        scope="published_script_conditions_not_project_held_out",config=cfg,source_calibration=calibration,
        test_labels_used_for_propensity=True,calibration_rows=len(selected),positive_threshold=3,
        evaluation_pool="entire_random_log",zero_positive_score=1,recall_denominator="min(k,n_positive)",
        raw_id_convention="source_unchanged",checkpoint_path=str(checkpoint),training_history=history,
        metrics=metrics,quick_run=epochs<1000,
        limitation="Paper prose and released script differ; these source-protocol scores are not shared benchmark results")
    folder=Path(output_dir or RESULTS_DIR);folder.mkdir(parents=True,exist_ok=True)
    path=folder/f"cdr_source_{dataset}_{run_id}.json"
    with path.open("x",encoding="utf-8") as stream: json.dump(result,stream,ensure_ascii=False,indent=2)
    md=path.with_suffix(".md")
    with md.open("x",encoding="utf-8") as stream:
        stream.write(f"# CDR released script: {dataset}\n\nDiagnostic under published script conditions; NOT project held-out evaluation.\n\n"
                     f"Uses 5% random evaluation labels for propensity. Positive rating >=3; empty-positive users score 1.\n\n"
                     f"NDCG@5: {metrics['NDCG@5']:.6f}; Recall@5 bounded: {metrics['Recall@5_bounded']:.6f}.\n\n"
                     f"Seed {seed}; epochs run {len(history)}; source {UPSTREAM_COMMIT}.\n")
    print(json.dumps(metrics,indent=2));print(path)
    return result


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset",choices=["coat","yahoo"],required=True)
    parser.add_argument("--epochs",type=int,default=1000)
    parser.add_argument("--seed",type=int,default=2020)
    parser.add_argument("--threads",type=int,default=2)
    args=parser.parse_args(argv)
    run_source(args.dataset,args.epochs,args.seed,args.threads)


if __name__=="__main__": main()
