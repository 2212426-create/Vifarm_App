# Trạng thái RecSys hiện hành

Mốc **20/10/2026: tích hợp CDR từ source khóa commit và Yahoo! R3**.
[Snapshot](state_snapshot.json) · [Định nghĩa mô hình](benchmarks/paper_model_alignment.md)
· [Giao thức](benchmarks/evaluation_protocol.md) · [Lệnh chạy](../README.md).

Source đã kiểm chứng:
`88769819bd670011c7a4667b0bff82458549ef0de8abee3f63e4d050e68a2943`.
Hash tính từ src/ và experiments/. Artifact cũ giữ hash gốc, không đại diện source mới.

## Triển khai hiện tại

- Bộ mặc định: MF-MSE, iDCF hai giai đoạn với feedback MSE, DR-BIAS+CDR-BCE.
  Ba mô hình huấn luyện độc lập.
- CDR Coat/Yahoo mặc định dùng bản `released`, port thuật toán source commit
  `6b4e6cca3df23b8d85b38fdc2e7eb5c812861ea9`. Giữ variance filter,
  output dropout, reverse imputation BCE, khởi tạo và thứ tự cập nhật.
  Benchmark dùng validation-only calibration và evaluator chung.
- CDR Eq. (7)/CV còn ở `--cdr-implementation equation`; đây là mặc định KuaiRand.
  Các lệnh tuning CDR cũ vẫn dùng Eq. (7), không dùng cho released.
- Yahoo đã tải đủ 311.704 biased / 54.000 random ratings, 15.400 user, 1.000 item.
  Chuyển ID 1-based đúng một lần; random log chia 1.620 validation / 3.780 test
  user, 16.200 / 37.800 dòng. Train/random overlap bằng 0.
- iDCF Yahoo dùng 7 câu trả lời survey thật, one-hot 39 chiều; 10.000 user thiếu
  survey nhận category thiếu. Đây là mở rộng dataset, chưa phải kết quả Yahoo
  được paper iDCF công bố; giả định nhân quả cho nhóm thiếu survey chưa xác minh.
- iVAE Coat/Yahoo 16/32/3; chọn checkpoint sau full-beta warm-up. KuaiRand giữ
  32/64/2. IViDR-approx chỉ chạy riêng và chưa hỗ trợ Yahoo. API giữ cấu hình phục vụ riêng.

## Kiểm chứng ở mốc này

Suite: **109 test, 108 đạt, 1 bỏ qua vì không có CUDA**.
[Log](archive/2026-10-20/yahoo_source_integration/model_tests.log).
Test đối chiếu 3 epoch CPU khớp từng trọng số của lớp CDR gốc với sai số bằng 0.
Có test ID/survey/missing proxy, data hash, train ba mô hình Yahoo và reload checkpoint.

[Validation CDR released ba seed](../results/released_cdr_coat_validation_20261020_yahoo_integration.json):
seed 42 / 43 / 44 chọn epoch 14 / 8 / 3, Val NDCG .507259 / .482685 / .495839.
Chỉ validation, không chấm test; không tuning và không chứng nhận chất lượng ngoài mẫu.
[Biên bản kiểm chứng và liên kết lượt chạy](../results/yahoo_source_integration_verification_20261020.json)
ghi riêng smoke, source-protocol và nguồn của từng lượt.

Smoke chạy đủ MF/iDCF/CDR trên Coat, Yahoo 64 user, KuaiRand 64 user;
thêm lượt Yahoo toàn dữ liệu 1 epoch feedback / 2 epoch iVAE.
Smoke xác nhận vận hành, không dùng điểm làm kết quả chất lượng/paper.

`cdr-source --dataset coat` chạy điều kiện script cho **NDCG .656665,
Recall bounded .667816**, làm tròn khớp .6567/.6678 của paper. Đường chạy này
dùng 5% nhãn random chấm điểm cho propensity, >=3, toàn random log,
zero-positive nhận 1; **không phải held-out benchmark chung**.
`cdr-source --dataset yahoo --epochs 1` đã chạy được nhưng chưa phải lượt đầy đủ.

Python 3.12.10, PyTorch 2.14.1+cpu, NumPy 2.5.4, pandas 3.0.6, CPU 2 thread.
Môi trường venv hiện chạy được; chưa kiểm chứng CUDA.

## Giới hạn và lịch sử

Chưa chạy benchmark chất lượng đầy đủ cho ba mô hình Yahoo ở source mới.
Cần chạy lệnh đầy đủ, khóa cấu hình bằng validation và báo nhiều seed trước
khi kết luận mô hình tốt hoặc tái lập paper. Không đổi nhãn/split để tăng điểm.

[Báo cáo Coat trước tích hợp](../results/benchmark_coat_all_16747d3add_20261020_194738_4bb0b674_v4.md)
thuộc source `d5bdd13e82c3`: MF .547612, iDCF .569884, CDR Eq. (7) .448514
Test NDCG@5. Các số này **không phải kết quả CDR released hiện hành**.
[Audit cũ](../results/cdr_followup_audit_20261020.json) và
[phân tích lịch sử](benchmarks/root_cause_analysis.md) giữ bằng chứng nguyên gốc.

Snapshot/code/docs trước tích hợp được giữ ở
[ZIP](archive/2026-10-20/yahoo_source_integration/before_integration.zip).
[Catalog kết quả](../results/CATALOG.md) phân biệt lịch sử, validation, smoke và
source-protocol. Chạy `python docs/check_docs.py` sau cập nhật.
