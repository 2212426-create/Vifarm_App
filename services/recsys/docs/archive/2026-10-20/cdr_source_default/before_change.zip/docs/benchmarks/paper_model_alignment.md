# Định nghĩa mô hình và đối chiếu mã công bố

Mốc tích hợp Yahoo/CDR: 20/10/2026. [Trạng thái và bằng chứng](../CURRENT_STATE.md).
MF, iDCF và CDR giữ loss riêng, huấn luyện độc lập; CDR không nạp checkpoint MF.

| Mô hình / đường chạy | Định nghĩa | Phạm vi |
| :-- | :-- | :-- |
| MF | Raw dot product + user/item bias, intercept cố định 0, MSE, Adam, Uniform(-.01,.01), decay mọi tham số | Theo mã MF của iDCF; Yahoo dùng cấu hình địa phương |
| iDCF | iVAE exposure/proxy, rồi MF + item/latent; feedback MSE; train 10 mẫu, inference mean | Coat iVAE 16/32/3 theo kích thước checkpoint công khai; Yahoo là mở rộng dataset |
| CDR `released` | Lớp DR-BIAS+CDR của source khóa commit; dot MF 4 chiều, BCE, variance filter, output probability dropout, reverse imputation BCE và loss sum | Mặc định benchmark Coat/Yahoo và coat-seeds; điều chỉnh split/calibration/checkpoint theo giao thức chung |
| CDR `equation` | Eq. (7), correction có inverse propensity, CV filter, chỉ dropout embedding, cùng chiều BCE | Biến thể theo công thức giữ để đối chứng; mặc định KuaiRand |
| IViDR-approx | Nhánh 2SLS địa phương, thiếu các MLP/reconstruction/loss đúng paper | Chỉ chạy tường minh; không hỗ trợ Yahoo |

## CDR tích hợp từ repository được chỉ định

Nguồn cố định:
[CDR_CIKM2023, commit 6b4e6cca](https://github.com/CrazyDumpling/CDR_CIKM2023/tree/6b4e6cca3df23b8d85b38fdc2e7eb5c812861ea9).
Port ở [released.py](../../src/causal/cdr/released.py), giữ giấy phép Apache-2.0.
Recommendation embedding dùng Xavier normal; imputation giữ mặc định nn.Embedding.
MC dùng mask không co giãn, gồm cả output xác suất.
Thứ tự RNG và cập nhật rec rồi imp được kiểm tra: 3 epoch CPU khớp từng tham số
lớp gốc với rtol=atol=0.

| Dataset | Dim | LR | Weight decay | Batch | Variance threshold | Dropout | G |
| :-- | --: | --: | --: | --: | --: | --: | --: |
| Coat | 4 | .05 | .001 | 128 | 10 | .5 | 4 |
| Yahoo | 4 | .05 | .0001 | 2048 | 10 | .7 | 1 |

Cấu hình từ script tương ứng. Benchmark chung có trần 100 epoch, patience 5,
calibration toàn bộ validation, population đúng n_users*n_items, nhãn >=4 và
evaluator chung. Các điều chỉnh ghi trong metadata `source_adaptations`.
Không gọi benchmark này là chạy nguyên điều kiện công bố.

`cdr-source --dataset coat|yahoo` giữ điều kiện script: seed 2020, trần 1000
epoch, dừng theo train loss với bộ đếm tích lũy, nhãn >=3, 5% nhãn random chấm
điểm dùng cho propensity, chấm toàn bộ random log, zero-positive nhận 1, recall
bounded. Yahoo giữ ID 1-based và dummy row/column như source.
Permutation trên flat catalog IDs thay mảng mọi cặp user/item để giảm RAM;
các cặp và thứ tự mẫu giống source trên CPU.
Đây là lượt đối chứng theo script, không thay thế held-out benchmark.

Paper và script khác nhau ở estimator, filter, dropout và protocol. Bản Eq. (7)
vẫn chạy bằng `benchmark ... --cdr-implementation equation`.
Tuning `tune --model cdr` và `tune-kr --model cdr` vẫn dành cho bản
Eq. (7), **không chọn cấu hình cho bản released**. Không chuyển điểm giữa hai bản.
Profile `paper` của Eq. (7) chặn warm-start, variance filter và cap propensity;
tên profile không chứng nhận tái lập thí nghiệm paper.

## Yahoo và iDCF

Yahoo! R3 từ cùng commit có 15.400 user, 1.000 item; 311.704 biased ratings và
54.000 random ratings. Loader chuyển raw ID từ 1 về 0 cho benchmark chung.
Survey có 7 câu hỏi của 5.400 user random-log, căn theo thứ tự raw user ID.
Mã hóa one-hot từng câu, thêm category thiếu cho 10.000 user không survey,
tổng 39 chiều. Không tạo proxy ngẫu nhiên hoặc suy proxy từ nhãn random/test.

iDCF Yahoo dùng survey thật làm proxy, exposure từ biased train; iVAE 16/32/3,
batch 512, patience 100; feedback dim 64, LR .0005, wd .000001, batch 2048.
Đây là cấu hình địa phương. Paper iDCF chưa báo Yahoo; giả định nhận dạng nhân
quả chưa được xác minh cho nhóm thiếu survey. Không gọi kết quả này là tái lập
Yahoo của paper iDCF.

iVAE chọn checkpoint và early stopping sau full-beta warm-up; lượt ngắn ghi
`budget_before_full_beta`. KuaiRand vẫn dùng iVAE ví dụ 32/64/2 và propensity
item-frequency cho CDR. API giữ ngân sách/triển khai phục vụ riêng.

Nguồn cấu hình: [config.py](../../src/training/config.py),
[train_idcf.py](../../src/causal/idcf/train_idcf.py).
Nguồn nghiên cứu:
[iDCF MF.py](https://github.com/BgmLover/iDCF/blob/main/MF.py),
[iDCF](https://github.com/BgmLover/iDCF),
[CDR paper](https://jiawei-chen.github.io/paper/CIKM23-CDR.pdf).
Xem [giao thức đánh giá](evaluation_protocol.md).
