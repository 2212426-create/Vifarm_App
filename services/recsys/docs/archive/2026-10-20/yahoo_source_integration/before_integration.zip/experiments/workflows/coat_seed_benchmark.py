"""Coat: MF, iDCF, IViDR (theo giai đoạn) và DR-BIAS + CDR, lặp 10 seed (42–51).

Mỗi seed chọn checkpoint bằng validation rồi chấm test một lần. Báo mean ± sample std
theo seed và Wilcoxon theo cặp seed trên cùng giao thức dự án.

    python experiments/run.py coat-seeds [--models MF iDCF IViDR "DR-BIAS + CDR"]
"""

import argparse
import json
import tempfile
import time
from pathlib import Path

import numpy as np
from scipy.stats import wilcoxon

from src.baselines.train_mf import train_baseline_mf
from src.causal.cdr.train_dr_bias_cdr import train_dr_bias_cdr
from src.causal.idcf.ividr_staged import mf_item_embeddings
from src.causal.idcf.train_idcf import fit_idcf_pipeline
from src.data_pipeline.coat_dataset import load_coat_processed
from src.training.config import mf_config, cdr_config
from src.evaluation.protocol import DEFAULT_SEEDS
from src.utils.artifacts import data_signature, digest, source_signature
from src.utils.helpers import RESULTS_DIR

MODELS = ("MF", "iDCF", "IViDR", "DR-BIAS + CDR")
STANDARD_MODELS = ("MF", "iDCF", "DR-BIAS + CDR")
# Cấu hình MF của tác giả iDCF (MF.py); cũng là treatment T của IViDR.
MF_CONFIG = mf_config("coat")


def run_seed(name, data, seed, ckpt):
    if name in ("MF", "IViDR"):
        mf = train_baseline_mf(dataset_name="coat", data_dict=data, seed=seed, checkpoint_dir=ckpt,
                               evaluate_test=name == "MF", checkpoint_tag=f"seeds_mf_{seed}", **MF_CONFIG)
        if name == "MF":
            return mf
        return fit_idcf_pipeline(data, "coat", seed, item_emb=mf_item_embeddings(mf["checkpoint_path"]),
                                 checkpoint_dir=ckpt, checkpoint_tag=f"seeds_ividr_{seed}")
    if name == "iDCF":
        return fit_idcf_pipeline(data, "coat", seed, checkpoint_dir=ckpt, checkpoint_tag=f"seeds_idcf_{seed}")
    if name != "DR-BIAS + CDR":
        raise ValueError(f"Unknown model: {name}")
    return train_dr_bias_cdr(dataset_name="coat", data_dict=data, seed=seed,
                             **cdr_config("coat"),
                             checkpoint_dir=ckpt, checkpoint_tag=f"seeds_cdr_{seed}")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", nargs="+", type=int, default=list(DEFAULT_SEEDS))
    parser.add_argument("--models", nargs="+", choices=MODELS, default=list(STANDARD_MODELS))
    args = parser.parse_args(argv)

    if len(set(args.seeds)) != len(args.seeds):
        parser.error("Seeds must be unique")
    data = load_coat_processed()
    identity = {"dataset": "coat", "seeds": args.seeds, "models": args.models,
                "data": data_signature(data), "code_sha256": source_signature()}
    path = Path(RESULTS_DIR) / f"coat_seeds_{digest(identity)}.json"
    rows = {name: [] for name in args.models}
    with tempfile.TemporaryDirectory() as ckpt:
        for name in args.models:
            for seed in args.seeds:
                t0 = time.time()
                r = run_seed(name, data, seed, ckpt)
                rows[name].append({"seed": seed, "NDCG@5": r["NDCG@5"], "Recall@5": r["Recall@5"],
                                   "best_epoch": r["best_epoch"], "best_val_ndcg": r["best_val_ndcg"],
                                   "selection_origin": r.get("selection_origin"),
                                   "metadata": r["metadata"],
                                   "seconds": round(time.time() - t0, 1)})
                print(f"{name} seed {seed}: NDCG@5={r['NDCG@5']:.4f} Recall@5={r['Recall@5']:.4f}", flush=True)

    summary = {}
    for name, runs in rows.items():
        nd = np.array([x["NDCG@5"] for x in runs]); rc = np.array([x["Recall@5"] for x in runs])
        summary[name] = {"NDCG@5_mean": float(nd.mean()), "NDCG@5_std": float(nd.std(ddof=1)) if len(nd) > 1 else None,
                         "Recall@5_mean": float(rc.mean()), "Recall@5_std": float(rc.std(ddof=1)) if len(rc) > 1 else None}
    pairs = {}
    for a in args.models:
        for b in args.models:
            if a < b:
                diff = np.array([x["NDCG@5"] for x in rows[a]]) - np.array([x["NDCG@5"] for x in rows[b]])
                p = float(wilcoxon(diff).pvalue) if np.any(diff) else 1.0
                pairs[f"{a} - {b}"] = {"mean_delta_ndcg": float(diff.mean()), "wilcoxon_p_over_seeds": p}
    report = {"identity": identity, "runs": rows, "summary": summary, "seed_pairs": pairs}
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [f"# Coat — {len(args.seeds)} seed ({args.seeds[0]}–{args.seeds[-1]})", "",
             "| Mô hình | NDCG@5 | Recall@5 |",
             "| :-- | --: | --: |"]
    for name, s in summary.items():
        nd_std = f"{s['NDCG@5_std']:.4f}" if s['NDCG@5_std'] is not None else "N/A"
        rc_std = f"{s['Recall@5_std']:.4f}" if s['Recall@5_std'] is not None else "N/A"
        label = "IViDR-approx (experimental)" if name == "IViDR" else name
        lines.append(f"| {label} | {s['NDCG@5_mean']:.4f} +/- {nd_std} | "
                     f"{s['Recall@5_mean']:.4f} +/- {rc_std} |")
    lines += ["", "| So sánh | ΔNDCG@5 trung bình | Wilcoxon p (theo cặp seed) |", "| :-- | --: | --: |"]
    lines += [f"| {k} | {v['mean_delta_ndcg']:+.4f} | {v['wilcoxon_p_over_seeds']:.3g} |" for k, v in pairs.items()]
    lines += ["", "Các mô hình được huấn luyện độc lập; CDR không nạp checkpoint MF.",
              "Giao thức dự án: rating >= 4, random-log user split 30/70; không phải tái lập mọi paper.",
              "IViDR-approx là bản xấp xỉ địa phương, bị loại khỏi bộ mặc định.", ""]
    path.with_suffix(".md").write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    print(f"Report: {path}")


if __name__ == "__main__":
    main()
