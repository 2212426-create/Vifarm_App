# Trạng thái RecSys hiện hành

Mốc rà soát: **20/10/2026, sau benchmark Coat và đối chứng CDR với mã công bố**.
Đây là điểm đọc đầu tiên. [Snapshot máy đọc được](state_snapshot.json).

## Nguồn và phạm vi

Source đã kiểm chứng:
`d5bdd13e82c351964eaead1572d4d8d185dd0b045521203ad7f63f5cb26266a1`.
Hash tính theo `src/` và `experiments/` qua
[`source_signature`](../src/utils/artifacts.py). Logic/config quyết định mô hình;
metadata JSON quyết định điểm thuộc phiên bản nào. Không đổi hash artifact cũ
để gán kết quả lịch sử cho source mới.

## Mô hình và cấu hình hiện tại

| Mô hình | Định nghĩa đang chạy | Giới hạn |
| :-- | :-- | :-- |
| MF | MSE, raw score với user/item bias, intercept cố định 0; Adam Uniform(-.01,.01), decay mọi tham số, không scheduler | Theo mã MF của iDCF; không đổi thành BCE |
| iDCF | iVAE exposure/proxy rồi MF + item/latent; feedback MSE; train 10 mẫu, inference mean | Coat iVAE 16/32/3 khớp kích thước checkpoint công khai; optimizer/schedule địa phương |
| DR-BIAS + CDR | BCE, Eq. (7), dot MF không bias, CV filter, MC 10; huấn luyện độc lập; không cap propensity | Bản triển khai công thức paper, khác script tạo số công bố; không phải tái lập thí nghiệm gốc |
| IViDR-approx | Bản xấp xỉ theo giai đoạn, chỉ chạy tường minh | Thiếu MLP0/1/2, reconstruction/BCE đúng paper; không thuộc bộ mặc định |

[MF/CDR config](../src/training/config.py), [iDCF config](../src/causal/idcf/train_idcf.py),
[đối chiếu paper/source](benchmarks/paper_model_alignment.md).
CDR Coat: dim 4, LR .1, wd .0001, batch 512, eta .1, patience 20, trần 100 epoch;
Naive Bayes propensity hiệu chỉnh từ random validation, không dùng nhãn test.

iVAE Coat dùng patience 100; chọn checkpoint và early stopping sau khi train đạt
beta đích. Lượt thiếu ngân sách ghi `budget_before_full_beta`. CDR cập nhật
recommendation rồi tính lại sai số để cập nhật imputation. Giữ MSE và BCE độc lập.
Benchmark lưu báo cáo và checkpoint riêng mỗi lượt; `--threads 2` đặt thread CPU.

## Benchmark đầy đủ người dùng vừa chạy

[Báo cáo](../results/benchmark_coat_all_16747d3add_20261020_194738_4bb0b674_v4.md),
[JSON](../results/benchmark_coat_all_16747d3add_20261020_194738_4bb0b674_v4.json).
Source khớp mốc trên; data hash `314c797e76745e659d14d7b603a7fb41debf0fbb119616242f1487afd2dcc861`.
Seed 42, full data, chọn checkpoint bằng validation, không phải smoke.

| Mô hình | Test NDCG@5 | Test Recall@5 | AUC macro-user | Epoch chọn |
| :-- | --: | --: | --: | --: |
| MF | .547612 | .529536 | .693124 | 23 |
| iDCF | .569884 | .551969 | .685997 | 24 |
| DR-BIAS + CDR | .448514 | .458145 | .622096 | 40 |

iDCF đã gần mốc .5744 trong paper iDCF, nhưng một seed không xác nhận tái lập
trung bình 10 seed. CDR thấp hơn MF trên giao thức chung; không dùng điểm validation
thay điểm test hoặc nói pipeline đạt test công thức là mô hình đã tốt.

## Kết luận rà soát CDR sau benchmark

[Evidence đầy đủ](../results/cdr_followup_audit_20261020.json),
[phân tích hiện hành](benchmarks/root_cause_analysis.md),
[runner và source công bố đã khóa commit](archive/2026-10-20/cdr_followup_audit/runners_and_source.zip).

- Hai ma trận train/test khớp mọi giá trị với repository CDR gốc tại commit
  `6b4e6cca3df23b8d85b38fdc2e7eb5c812861ea9`; khác byte chỉ do CRLF.
  Checkpoint khớp source, data và epoch trong báo cáo.
- Chạy các lớp và điều kiện script công bố cho NDCG@5 **.656665** và Recall
  bounded **.667816**, làm tròn khớp .6567/.6678 ở Table 2. Script dùng rating
  >=3, toàn bộ random log để chấm, user không positive nhận điểm 1, và 5% nhãn
  random chấm điểm để ước lượng propensity. Đây là chẩn đoán theo source, **không
  phải held-out benchmark của dự án**. Paper prose lại nói rating >3 và split 10/90.
- Giữ nguyên checkpoint của script rồi chấm theo nhãn >=4 và test pool dự án:
  NDCG .479693. Kết quả này vẫn không phải held-out độc lập vì checkpoint gốc
  đã dùng một phần nhãn random để hiệu chỉnh propensity.
- Trong benchmark hiện tại, epoch 40 lọc 93.49% observed / 92.78% direct imputation.
  Đối chứng validation: eta .1 đạt .498562; IPS không imputation đạt .494527;
  eta >=3 giữ toàn bộ imputation chỉ đạt .363517. Nới bộ lọc không chữa chất lượng.
- Probe checkpoint với 200 MC samples: khoảng 67.46% imputation trên validation
  thỏa điều kiện poisonous của paper; mean error sau dropout lệch nhiều so với
  error imputation được fit bằng forward không dropout. Đây là chẩn đoán chất
  lượng của nhánh imputation, không tự chứng minh công thức Eq. (7) bị lập trình sai.
  Paper quy định không dropout khi train imputation; không đổi điều này tùy tiện.
- Lớp gốc chạy với nhãn/split dự án và calibration chỉ validation đạt .469430
  validation; đổi riêng chiều BCE imputation đạt .512568 tại eta .1 trong một
  probe. Các thay đổi đơn lẻ không chứng minh tái lập paper hoặc cải thiện test.

Đợt rà soát này không sửa runtime, không chọn lại cấu hình theo test. Các phép
đối chứng validation và chẩn đoán source được tách rõ trong artifact.

## Kiểm chứng và validation trước benchmark

Suite: **104 test, 103 đạt, 1 CUDA test bỏ qua**.
[Log kiểm thử](archive/2026-10-20/coat_pipeline_fix/model_tests.log),
[CLI smoke cả ba mô hình](archive/2026-10-20/coat_pipeline_fix/coat_smoke.log).
Đây là kiểm chứng ở source trên; không chạy lại suite trong mỗi lần đọc tài liệu.

[Validation bản chốt](../results/coat_pipeline_fix_validation_20261020.json):
MF seed 42 .618987; iDCF 42/43/44 .605897/.589225/.602283;
CDR .498562/.497547/.491869. Mean CDR .495993, sample std .003607.
Các seed CDR cũng tham gia chọn cấu hình; không phải kiểm chứng ngoài mẫu độc lập.
[Search evidence](../results/coat_pipeline_fix_search_20261020.json) là một phần
miền tuning, không phải đủ 1120 cấu hình. Môi trường: Python 3.12.10, NumPy 2.5.4,
PyTorch 2.14.1+cpu, pandas 3.0.6, CPU 2 thread; chưa kiểm chứng CUDA.

## Giao thức và việc còn thiếu

Biased train; Coat positive >=4, random log chia theo user 30/70 seed 1234.
Ranking trên logged candidates; macro loại user không positive; Recall chia
toàn bộ positive. Giữ và công bố train/random overlap.
CDR dùng validation cho cả hiệu chỉnh propensity và chọn cấu hình/checkpoint;
test giữ riêng. [Giao thức](benchmarks/evaluation_protocol.md).

Muốn so số Table 2 cần ghi đúng điều kiện script/paper và công bố khác biệt giữa
hai nguồn. Benchmark chung hiện tại phải giữ evaluator thống nhất. Muốn cải thiện
benchmark đó cần kiểm chứng nhánh imputation và đủ tuning trên validation, khóa
cấu hình rồi báo nhiều seed; không đổi threshold chỉ để lấy điểm cao.

KuaiRand vẫn dùng kiến trúc iVAE ví dụ 32/64/2 và propensity proxy item-frequency;
API có ngân sách riêng. Không suy từ Coat rằng đã tái lập KuaiRand hoặc chất lượng
phục vụ. [API](api/colab_api_guide.md). IViDR còn thiếu các thành phần đúng paper.

## Kết quả lịch sử

Ở source trước sửa `36230d1cd908`,
[benchmark cũ](../results/benchmark_coat_all_429e263db0_v4.md) có test MF .547612,
iDCF .463745, CDR .376982. Không chuyển các số này sang source mới.
[Validation CDR cũ](../results/cdr_paper_method_validation_37b126f2c13fcea9.json)
và [warm-start ablation](../results/cdr_eq7_validation_6346597634257fd0.json) giữ
nguyên; ablation chọn MF epoch 0 không phải bằng chứng CDR cải thiện.
Port `cdr-author` cũ không tương đương bitwise source; lần đối chứng source mới
ở evidence trên dùng trực tiếp các định nghĩa lớp công bố, có runner/provenance riêng.

[Catalog kết quả](../results/CATALOG.md) · [Mục lục](README.md) ·
[Quy tắc bảo toàn](MAINTENANCE.md). Không ghi đè artifact; đăng ký file mới rồi
chạy `python docs/check_docs.py`.
