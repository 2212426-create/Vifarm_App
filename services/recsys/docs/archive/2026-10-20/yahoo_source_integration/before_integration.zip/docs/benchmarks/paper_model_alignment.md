# Đối chiếu mô hình với bài báo — 20/10/2026

**Tài liệu hiện hành về định nghĩa phương pháp.** Trạng thái và bằng chứng:
[CURRENT_STATE](../CURRENT_STATE.md). Đây chưa phải chứng nhận tái lập đầy đủ paper.

Các mô hình phải giữ mục tiêu riêng của phương pháp. MF-MSE và CDR-BCE được
huấn luyện độc lập; không chuyển score MF-MSE thành logit BCE bằng cách nạp
checkpoint rồi gọi đó là CDR nguyên bản. Các lượt ghép cũ chỉ là ablation lịch sử.

| Mô hình | Định nghĩa sử dụng | Cấu hình / trạng thái |
| :-- | :-- | :-- |
| MF của iDCF | Score thô = tích vô hướng + user/item bias; global intercept cố định 0; MSE | Adam, decay mọi tham số, không scheduler, Uniform(-.01,.01) cho embedding và bias |
| iDCF | iVAE trên exposure/proxy, sau đó MF + tích vô hướng item/latent; feedback MSE; training lấy 10 mẫu, inference dùng mean | Coat latent 16, hidden 32, 3 lớp theo checkpoint đã tune; patience 100 và chỉ chọn sau full-beta warm-up. LR .0005, wd .000001, L2 .01 là mặc định địa phương, không suy từ checkpoint |
| DR-BIAS + CDR | MF dot-product không bias; BCE; Eq. (7) chuẩn hóa theo catalog; MC 10 lần bỏ 50% chiều embedding; giữ imputation nếu std/mean < eta | Khởi tạo độc lập; Adam LR cố định; không cap inverse propensity; eta chọn từ validation |
| IViDR-approx | Bản địa phương dùng hồi quy item và hệ số cố định, chưa có MLP0/MLP1/MLP2 của Eq. (6)–(9), chưa tái tạo đúng Eq. (10); feedback hiện là MSE trong khi Eq. (25) quy định BCE | **Không phải IViDR chuẩn. Loại khỏi bộ mặc định.** Chỉ chạy riêng để nghiên cứu |

Nguồn cấu hình thực thi: [`config.py`](../../src/training/config.py),
[`train_idcf.py`](../../src/causal/idcf/train_idcf.py).
CDR Coat giữ dim 4 từ script tác giả; LR, wd, batch được kiểm tra trên một phần
miền tuning paper bằng validation (chưa chạy đủ grid). Cấu hình đang dùng lấy từ
`cdr_config("coat")`. KuaiRand giữ dim 4, LR .05, batch 2048, wd .0001 từ script.
Eta .1 nằm trong miền tuning của paper, không tuyên bố là tối ưu cho mọi dataset.
Trần feedback model 100 epoch và chọn checkpoint bằng validation là ngân sách
chạy của dự án; script CDR gốc có trần 1000 và dừng theo train loss.
Tuning MF dùng 10 tổ hợp LR × weight decay theo `MF.py`; CDR dùng 1.120 tổ hợp
LR × weight decay × eta × batch theo paper §4.1, không còn sàng lọc từng tham số riêng.
Baseline đứng đầu grid; `--quick` chỉ chạy cấu hình đầu để kiểm tra vận hành.

**Sau sửa pipeline Coat:** kiến trúc iVAE đã khớp kích thước checkpoint công khai
`coat_val_ivae_exposure_best.pt`; không tự tải/nạp trọng số tác giả khi chạy mặc
định. Early stopping và chọn checkpoint bắt đầu sau khi train thực sự đạt beta
đích, bỏ các checkpoint warm-up khỏi cạnh tranh. Ngân sách quá ngắn được ghi
`budget_before_full_beta`, không gọi là đã hội tụ. KuaiRand vẫn dùng kiến trúc ví
dụ 32/64/2, chưa xác minh checkpoint đã tune. [Phân tích](root_cause_analysis.md).

## CDR: ưu tiên công thức bài báo khi khác mã công bố

Paper §3.1 quy định CV = std/mean và Eq. (7) dùng correction có inverse propensity.
Mã công bố lọc bằng variance và dùng estimator khác; vì vậy benchmark hiện dùng
định nghĩa trong paper, còn `cdr-author`/`cdr-tune` là các port chẩn đoán riêng.
Port dùng Xavier cho cả hai mô hình, trong khi lớp imputation của source tác giả
giữ khởi tạo mặc định của embedding; không gọi port là tái lập bitwise hoặc chính
xác toàn bộ script. Không đồng nhất kết quả của hai đường chạy.

Recommendation embedding khởi tạo Xavier normal như `MF_BaseModel` của tác giả.
Imputation embedding giữ khởi tạo mặc định của `nn.Embedding`, như
`MF_McdropoutModel`. MC chỉ bỏ chiều embedding bằng mask không co giãn;
không dropout output probability, vì paper chỉ mô tả dropout embedding.
Rec/imp dùng cùng một định nghĩa BCE; phía không cập nhật được detach.
Trainer cập nhật recommendation trước, rồi tính lại sai số bằng trọng số mới để
cập nhật imputation; không dùng logits cũ từ trước bước recommendation.

`training_profile=paper` chặn warm-start, estimator cũ, variance filter,
backbone có bias, scheduler và cap propensity. Muốn chạy các ablation này cần
`training_profile=experimental` tường minh; checkpoint ghi đầy đủ lựa chọn.
Checkpoint cũ thiếu `backbone` vẫn dựng kiến trúc có bias cũ để suy luận đúng trọng số.

## Phạm vi còn khác thực nghiệm công bố

Định nghĩa mô hình và giao thức dữ liệu là hai phần cần kiểm chứng riêng:

- Benchmark/tuning dự án vẫn dùng random-log user split 30/70 và rating >= 4.
  CDR paper §4.1 dùng 10/90; script Coat công bố lại dùng rating >= 3 và toàn bộ
  random log. Vì vậy báo cáo mới không đặt số của paper cạnh số dự án để kết luận hơn/kém.
- Coat mặc định dùng Naive Bayes `P(O=1|Y)` theo mã CDR, hiệu chỉnh từ toàn bộ
  random validation, gồm user không positive; không đọc nhãn held-out test.
  Dùng đúng population size, không giữ lỗi `max_user_id*max_item_id` của script.
  `provided_coat` là lựa chọn đối chứng tường minh. Khác tập calibration so với
  source tác giả và chưa khớp toàn bộ thí nghiệm paper. KuaiRand/API vẫn dùng
  proxy item-frequency; **chưa phải cấu hình tái lập đầy đủ**.
- Dữ liệu KuaiRand sau lọc khác kích thước trong paper. Cặp train lặp của CDR
  được gộp mean label; ranking gộp any-positive. Quy tắc này được ghi metadata.
- iVAE dùng MC ELBO với nhiễu validation cố định để chọn checkpoint; mã tác giả
  dùng một lượt lấy mẫu. Không khẳng định khớp quỹ đạo optimizer hoặc tái lập điểm gốc.
- IViDR cần triển khai lại treatment projection theo từng item, các MLP học hệ số,
  reconstruction và loss BCE theo paper trước khi đưa lại vào bộ mô hình chuẩn.

Các giới hạn trên được công bố thay vì gắn nhãn mọi kết quả là “tái lập paper”.
Đọc [giao thức đánh giá](evaluation_protocol.md) và [kết quả có phiên bản](../../results/README.md).

## Nguồn gốc

- [iDCF MF.py](https://github.com/BgmLover/iDCF/blob/main/MF.py),
  [models/mf.py](https://github.com/BgmLover/iDCF/blob/main/models/mf.py),
  [iDCF.py](https://github.com/BgmLover/iDCF/blob/main/iDCF.py),
  [ivae_exposure.py](https://github.com/BgmLover/iDCF/blob/main/ivae_exposure.py),
  [argparser.py](https://github.com/BgmLover/iDCF/blob/main/argparser.py),
  [notebook xuất latent](https://github.com/BgmLover/iDCF/blob/main/save_ae_params.ipynb),
  [checkpoint Coat đã tune](https://github.com/BgmLover/iDCF/blob/main/tuned_models/coat_val_ivae_exposure_best.pt).
- [CDR paper](https://jiawei-chen.github.io/paper/CIKM23-CDR.pdf),
  [MF_mcdropout.py](https://github.com/CrazyDumpling/CDR_CIKM2023/blob/main/CDR/MF_mcdropout.py),
  [script Coat](https://github.com/CrazyDumpling/CDR_CIKM2023/blob/main/CDR/mf_cdr_bias_coat.py),
  [script KuaiRand](https://github.com/CrazyDumpling/CDR_CIKM2023/blob/main/CDR/mf_cdr_bias_kuairand.py).
- [IViDR paper](https://arxiv.org/pdf/2410.12451), đối chiếu Eq. (6)–(10), (25).
