# Catalog kết quả RecSys — mốc 20/10/2026

Phân loại theo nội dung JSON và source hash, không suy ngày chạy từ tên hoặc mtime.
Artifact giữ nguyên byte. Bảng dưới chỉ dẫn cách đọc, không thay metadata và không trộn điểm.
[Trạng thái hiện hành](../docs/CURRENT_STATE.md) · [Checksum](../docs/catalog.json).

## Benchmark đầy đủ sau sửa và audit CDR

[Báo cáo người dùng vừa chạy](benchmark_coat_all_16747d3add_20261020_194738_4bb0b674_v4.md)
· [JSON](benchmark_coat_all_16747d3add_20261020_194738_4bb0b674_v4.json):
full-data seed 42, source `d5bdd13e82c3`, Test NDCG MF .547612, iDCF .569884,
CDR .448514. Không dùng validation hoặc diagnostic thay cho bảng này.

[Audit CDR sau benchmark](cdr_followup_audit_20261020.json) giữ kiểm tra dữ liệu,
checkpoint, validation controls và đối chứng script công bố. Script diagnostic
đạt .656665 NDCG / .667816 Recall bounded, có dùng 5% nhãn random chấm điểm cho
propensity; **không phải held-out benchmark dự án**. Giữ nguyên checkpoint đó
chấm >=4/test pool dự án còn .479693, vẫn chỉ là diagnostic.
[Phân tích](../docs/benchmarks/root_cause_analysis.md) nêu khác biệt paper/source.

## Validation sau sửa pipeline Coat

[Validation ba seed](coat_pipeline_fix_validation_20261020.json): CDR và iDCF
huấn luyện đầy đủ trên train, không gọi held-out test; MF seed 42 làm đối chứng.
CDR đã chọn cấu hình qua một phần miền tuning paper và ba seed validation;
mean/std ở đây là mô tả quá trình chọn cấu hình, không phải benchmark độc lập.
[Search evidence](coat_pipeline_fix_search_20261020.json) giữ cấu hình và source
của từng trial phát triển; không đổi chúng sang source của bản chốt.

[CLI smoke Coat sau sửa — JSON](benchmark_coat_all_quick_13e80854d6_20261020_192736_117c64b0_v4.json)
· [Markdown](benchmark_coat_all_quick_13e80854d6_20261020_192736_117c64b0_v4.md):
cả ba mô hình chạy được ở source `d5bdd13e82c3`, feedback 1 epoch / iVAE 2 epoch;
chỉ xác nhận vận hành, không dùng điểm lượt này so với benchmark đầy đủ hoặc paper.

## Benchmark đầy đủ trước sửa pipeline Coat

[Coat, seed 42 — báo cáo](coat_full_20261020_185436_60df72/benchmark_coat_all_429e263db0_v4.md)
· [JSON](coat_full_20261020_185436_60df72/benchmark_coat_all_429e263db0_v4.json)
· [yêu cầu/cấu hình chạy](coat_full_20261020_185436_60df72/request.json)
· [biên bản hoàn tất](coat_full_20261020_185436_60df72/completion.json).
MF/iDCF/CDR chạy đầy đủ dữ liệu, cấu hình mặc định và early stopping; source
`36230d1cd908`, data `314c797e7674`. Chưa tuning, một seed, không phải tái lập paper.
IViDR-approx không thuộc lượt này. Log, script chạy và checkpoint riêng được giữ để đối chiếu.

Lượt người dùng chạy lại: [báo cáo](benchmark_coat_all_429e263db0_v4.md) ·
[JSON](benchmark_coat_all_429e263db0_v4.json). Cùng điểm, source/data và seed với
lượt trong thư mục riêng; không coi là seed độc lập hoặc bằng chứng độ ổn định.
[Phân tích báo cáo](coat_report_analysis_20261020.json) chỉ đọc metadata, lịch sử,
trọng số propensity của train và kiến trúc checkpoint công khai của tác giả;
không có retraining, tuning hoặc lần chấm test mới. Kết luận và giới hạn nằm ở
[root cause analysis](../docs/benchmarks/root_cause_analysis.md).

## Validation, chẩn đoán và kết quả lịch sử

| Artifact | Phạm vi sử dụng | Nguồn ghi trong JSON |
| :-- | :-- | :-- |
| [benchmark_all_8c15e5d925_v4.json](benchmark_all_8c15e5d925_v4.json) · [MD](benchmark_all_8c15e5d925_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | `a9fdeb72ccd6` — source lịch sử |
| [benchmark_coat_all_003679088f_v4.json](benchmark_coat_all_003679088f_v4.json) · [MD](benchmark_coat_all_003679088f_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | 2 source hash khác mốc hiện hành; kiểm tra từng metadata |
| [benchmark_coat_all_19d70ea039_v4.json](benchmark_coat_all_19d70ea039_v4.json) · [MD](benchmark_coat_all_19d70ea039_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | `22ea114a3bdb` — source lịch sử |
| [benchmark_coat_ividr_9cf02b470b_v4.json](benchmark_coat_ividr_9cf02b470b_v4.json) · [MD](benchmark_coat_ividr_9cf02b470b_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | `946754273f79` — source lịch sử |
| [benchmark_kuairand_all_2edb44f179_v4.json](benchmark_kuairand_all_2edb44f179_v4.json) · [MD](benchmark_kuairand_all_2edb44f179_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | 3 source hash khác mốc hiện hành; kiểm tra từng metadata |
| [benchmark_kuairand_all_32e6ded9ad_v4.json](benchmark_kuairand_all_32e6ded9ad_v4.json) · [MD](benchmark_kuairand_all_32e6ded9ad_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | 2 source hash khác mốc hiện hành; kiểm tra từng metadata |
| [cdr_author_protocol_coat_thr3.json](cdr_author_protocol_coat_thr3.json) | Port chẩn đoán; dùng một phần nhãn tập chấm điểm cho propensity; thiếu source hash; không xác nhận tái lập paper | Không có source hash; chưa đủ provenance |
| [cdr_eq7_validation_6346597634257fd0.json](cdr_eq7_validation_6346597634257fd0.json) | Warm-start ablation đã bị thay thế; ba seed chọn MF epoch 0; không đại diện CDR độc lập | `999931b4f5cc` — source lịch sử |
| [cdr_idcf_tune_coat.json](cdr_idcf_tune_coat.json) | Port/filter variance, tuning theo giao thức dự án; thiếu source hash; không thuộc cấu hình CDR hiện hành | Không có source hash; chưa đủ provenance |
| [cdr_paper_method_validation_37b126f2c13fcea9.json](cdr_paper_method_validation_37b126f2c13fcea9.json) | CDR độc lập trước sửa pipeline, ba seed; chỉ validation; có ghi riêng smoke hai dataset; chưa tuning/test | `36230d1cd908` — source trước sửa |
| [coat_seeds_7ae4942b7c4a9f32.json](coat_seeds_7ae4942b7c4a9f32.json) · [MD](coat_seeds_7ae4942b7c4a9f32.md) | CDR lịch sử trước cơ chế giữ epoch 0; không đại diện CDR huấn luyện độc lập | `e5106d9db885` — source lịch sử |
| [coat_seeds_7d37e1975c96a410.json](coat_seeds_7d37e1975c96a410.json) · [MD](coat_seeds_7d37e1975c96a410.md) | iDCF và IViDR-staged cũ; IViDR dùng alpha_residual=1; không phải bản đúng paper | `02582b7e7987` — source lịch sử |
| [coat_seeds_c25da453e8909e5b.json](coat_seeds_c25da453e8909e5b.json) · [MD](coat_seeds_c25da453e8909e5b.md) | Bộ nhiều seed cũ; có kiến trúc joint/CDR cũ; không gán lại số cho mô hình hiện hành | `fbe2d03c1f3d` — source lịch sử |
| [tuning_kuairand_all_e25_4deb0568781e5d74_v4.json](tuning_kuairand_all_e25_4deb0568781e5d74_v4.json) · [MD](tuning_kuairand_all_e25_4deb0568781e5d74_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | `22ea114a3bdb` — source lịch sử |

## Quy tắc trích kết quả

- Trích JSON gốc kèm dataset, mô hình/biến thể, loss, source/data hash, seed và protocol.
- Nếu một artifact có nhiều source hash, không gọi toàn bộ là một phiên bản source đồng nhất.
- Không dùng validation hoặc smoke thay held-out test; không dùng test nhiều lần để chọn cấu hình.
- Markdown cũ có thể kèm bảng paper hoặc kết luận lỗi thời. Giữ nguyên để đối chiếu, không coi phần diễn giải đó là kết luận hiện tại.
- Với port thiếu source hash, không suy mã đã chạy từ file source đang có hôm nay.
- Lượt chạy mới phải đăng ký riêng trong catalog; không đổi nhãn hay ghi đè artifact cũ.
