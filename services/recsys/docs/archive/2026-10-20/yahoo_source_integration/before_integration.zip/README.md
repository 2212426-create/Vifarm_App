# RecSys: MF, iDCF và DR-BIAS + CDR

**Đọc trước:** [trạng thái hiện hành và giới hạn bằng chứng](docs/CURRENT_STATE.md).
IViDR hiện là bản xấp xỉ để nghiên cứu, chưa thuộc bộ chạy mặc định.
Mốc tài liệu: 20/10/2026. [Mục lục](docs/README.md) · [Kết quả có phiên bản](results/CATALOG.md).

## Khởi chạy

Chạy từ `services/recsys`:

```powershell
py -3.12 -m venv venv
.\venv\Scripts\python.exe -m pip install -r requirements.txt
.\venv\Scripts\python.exe experiments\run.py test
.\venv\Scripts\python.exe docs\check_docs.py
```

Lệnh tạo môi trường ở trên là hướng dẫn cài mới. Môi trường đã kiểm chứng ở mốc
20/10 và giới hạn Windows Application Control được ghi tại CURRENT_STATE;
không mặc định rằng `venv` hiện có đã dùng được.

Dữ liệu cần có ở `data/raw/coat/`: `train.ascii`, `test.ascii`, `propensities.ascii`,
`user_item_features/user_features.ascii`, `user_item_features/item_features.ascii`.
KuaiRand cần hai standard log `log_standard_4_08_to_4_21_pure.csv`,
`log_standard_4_22_to_5_08_pure.csv`, random log `log_random_4_22_to_5_08_pure.csv`
và `user_features_pure.csv` trong `data/raw/kuairand_pure/data/` hoặc `kuairand_pure/`.
Loader ưu tiên `./data/`, rồi `../data/`; `data_dir` tường minh không tự fallback.

## Lệnh thực nghiệm

Chạy thử cả ba mô hình trên Coat bằng cấu hình mặc định đã sửa:

```powershell
.\venv\Scripts\python.exe experiments\run.py benchmark --dataset coat --model all --device cpu --threads 2
```

Lệnh này chạy đầy đủ dữ liệu, chọn checkpoint bằng validation rồi chấm test.
iVAE cần hoàn tất warm-up trước khi early stopping có hiệu lực; mỗi lần chạy tạo
báo cáo riêng trong `results/` và checkpoint trong `checkpoints/benchmark_runs/`.
CDR Coat mặc định hiệu chỉnh propensity Naive Bayes bằng validation; nhãn test
không tham gia huấn luyện. Kiểm chứng của bản sửa: [CURRENT_STATE](docs/CURRENT_STATE.md).
Để kiểm tra vận hành nhanh, thêm `--quick --epochs 1 --ivae-epochs 2`; điểm lượt
ngắn này không phải kết quả đánh giá chất lượng.

| Lệnh sau `experiments/run.py` | Phạm vi |
| :-- | :-- |
| `test` | Suite kiểm thử; không phải benchmark chất lượng |
| `smoke` | MF/iDCF/CDR trên Coat và KuaiRand 64 user; chỉ kiểm tra vận hành |
| `benchmark --dataset coat --model mf` | Huấn luyện/evaluate một mô hình; đổi dataset/model khi cần |
| `benchmark --dataset coat --model idcf` | iDCF hai giai đoạn với cấu hình mặc định của pipeline |
| `benchmark --dataset coat --model cdr` | CDR huấn luyện từ đầu, không nạp MF |
| `benchmark --dataset coat --model cdr --cdr-propensity provided_coat` | Đối chứng với propensity file Coat, vẫn giữ Eq. (7); không phải cấu hình mặc định |
| `tune --model mf` / `tune-kr --model mf` | Chọn cấu hình trên validation rồi chấm checkpoint đã chọn |
| `tune --model cdr` | Grid CDR; 1.120 cấu hình. `--quick` chỉ chạy baseline |
| `coat-seeds` | MF/iDCF/CDR mặc định seed 42–51; cấu hình cố định |
| `mf` | MF-MSE mặc định; lựa chọn loss/optimizer khác là thí nghiệm tường minh |
| `optimizers` | Thí nghiệm Adam/SGD riêng; đọc loss và config của lệnh |
| `cdr-author` / `cdr-tune` | Port/chẩn đoán riêng, không phải benchmark mặc định hoặc tái lập bitwise |
| `evaluate --dataset coat --checkpoint FILE` | Chấm checkpoint tương thích, không huấn luyện lại |
| `protocol` | In quy tắc evaluator |
| `clean` / `clean --apply` | Xem trước / dọn checkpoint, log, bytecode; giữ raw data và báo cáo |

Mỗi lệnh có `--help`. Giá trị có dấu `/` trong bảng là các lệnh riêng, không phải
cú pháp shell để chép nguyên dòng. `--model all` dùng MF/iDCF/CDR;
`--model ividr` chạy IViDR-approx riêng và không dùng làm kết quả IViDR chuẩn.

## Nguồn cấu hình và đánh giá

- [Định nghĩa mô hình và lựa chọn khác paper](docs/benchmarks/paper_model_alignment.md).
- [Giao thức đánh giá duy nhất của benchmark dự án](docs/benchmarks/evaluation_protocol.md).
- [MF/CDR config](src/training/config.py), [iDCF config](src/causal/idcf/train_idcf.py).
- [Trạng thái, kiểm chứng và việc còn thiếu](docs/CURRENT_STATE.md).

Giữ loss riêng của từng phương pháp: MF/iDCF dùng MSE; CDR dùng BCE và huấn luyện
độc lập. Tên profile `paper` không chứng nhận đã tái lập điểm paper.
Không suy ra cấu hình hiện tại từ slide hoặc báo cáo cũ có cùng tên `v4`.

## API TopTop

API huấn luyện MF/CDR trên tương tác ứng dụng với cấu hình phục vụ riêng;
user mới dùng popularity. Không có IViDR phục vụ nguyên bản.
[Hướng dẫn API/Colab](docs/api/colab_api_guide.md).

```powershell
.\venv\Scripts\python.exe -m uvicorn src.api.app:app --port 8000
```
