# RecSys: MF, iDCF, IViDR và DR-BIAS + CDR

Benchmark trên Coat/KuaiRand-Pure và API gợi ý TopTop. Chạy mọi lệnh từ thư mục
`services/recsys`. [Tài liệu](docs/README.md) · [Kết quả và phiên bản](results/README.md).

## Môi trường

```powershell
py -3.12 -m venv venv
.\venv\Scripts\python.exe -m pip install -r requirements.txt
.\venv\Scripts\python.exe experiments\run.py test
```

Dữ liệu raw cần có:

```text
data/raw/coat/
  train.ascii
  test.ascii
  propensities.ascii
  user_item_features/user_features.ascii
  user_item_features/item_features.ascii
data/raw/kuairand_pure/data/
  log_standard_4_08_to_4_21_pure.csv
  log_standard_4_22_to_5_08_pure.csv
  log_random_4_22_to_5_08_pure.csv
  user_features_pure.csv
```

Loader ưu tiên `./data/`, nếu không có mới dùng `../data/`. KuaiRand hỗ trợ file
trực tiếp trong `kuairand_pure/`. `data_dir` tường minh không tự fallback.

## Lệnh chính

| Lệnh sau `experiments/run.py` | Mục đích |
| :-- | :-- |
| `test` | Toàn bộ test dữ liệu, metric, API, checkpoint và workflow |
| `smoke` | MF, iDCF, CDR trên Coat và mẫu 64 user KuaiRand; chỉ xác minh vận hành |
| `benchmark --dataset coat/kuairand --model mf/idcf/ividr/cdr` | Huấn luyện đầy đủ dữ liệu, một seed |
| `tune --model mf/cdr` | Tuning Coat bằng validation |
| `tune-kr --model mf/cdr` | Tuning KuaiRand bằng validation |
| `coat-seeds` | Cấu hình cố định, mặc định seed 42–51 |
| `mf` / `optimizers` | Thử loss/optimizer hoặc so Adam và SGD |
| `cdr-author` / `cdr-tune` | Bản port CDR theo giao thức tác giả / dự án; workflow riêng |
| `evaluate --dataset coat/kuairand --checkpoint FILE` | Chấm checkpoint đã chọn, không train lại |
| `protocol` | In quy tắc metric |
| `clean` / `clean --apply` | Xem trước / xóa checkpoint, log và bytecode |

Mỗi lệnh hỗ trợ `--help`. `clean` không xóa raw data, báo cáo JSON/Markdown hay tài liệu.

## Cấu hình huấn luyện và tuning

Nguồn cấu hình chung: [`src/training/config.py`](src/training/config.py).
Benchmark/tuning MF dùng Adam + MSE trên điểm thô, decay mọi tham số, không scheduler,
global intercept cố định 0. Coat: LR 5e-4, dim 64, batch 512;
KuaiRand: LR 5e-5, dim 64, batch 2048. Trần 100 epoch, patience 5.
Grid tuning luôn có baseline hiện hành; epoch/patience tường minh ghi đè mặc định từng model.
CLI `mf` và API TopTop cũng dùng MF-MSE; BCE chỉ chạy khi chọn tường minh cho ablation.

Khởi tạo MF/iDCF mặc định `author_uniform`: Uniform(-.01,.01) cho embedding và bias,
theo `models/mf.py` của iDCF. `--init-scheme normal` dành cho ablation. Checkpoint ghi rõ lựa chọn; chưa coi kết quả địa phương
là tái lập nguyên bản paper chỉ vì cùng loss.

iDCF/IViDR huấn luyện hai giai đoạn. `--dim`, `--lr`, `--batch-size` của benchmark
áp dụng cho stage 2 và MF treatment nếu có. Stage 1 có `--ivae-epochs`, `--ivae-lr`,
`--ivae-batch-size`, `--latent-dim`. `--device cpu/cuda` áp dụng cho cả hai stage;
mặc định tự chọn. iVAE chọn checkpoint bằng MC ELBO với 8 mẫu và nhiễu validation cố định,
độc lập RNG training. Checkpoint lưu cấu hình và thông tin stage 1.

```powershell
.\venv\Scripts\python.exe experiments\run.py benchmark --dataset coat --model idcf --dim 32 --lr 0.0001 --batch-size 128 --ivae-batch-size 64 --latent-dim 16 --device cpu
.\venv\Scripts\python.exe experiments\run.py tune --model mf --epochs 100 --patience 5
.\venv\Scripts\python.exe experiments\run.py tune-kr --model mf
.\venv\Scripts\python.exe experiments\run.py coat-seeds --models MF iDCF "DR-BIAS + CDR"
```

Coat và KuaiRand mặc định trần 100 epoch cho feedback model;
`--epochs`, `--epochs-coat`, `--epochs-kr` ghi đè tương ứng.
`--quick` giảm epoch; `--smoke-users` chỉ thu nhỏ KuaiRand khi đi cùng `--quick`.

CDR mặc định dùng Eq. (7), revision `cdr_eq7_bce_v1`: correction có inverse propensity,
chuẩn hóa theo số cặp observed / toàn catalog, lọc std/mean < eta (mặc định 0.1),
MC dropout 10 mẫu. Rec/imp dùng cùng chiều BCE trên logits ổn định số học.
Grid CDR theo miền paper: LR × weight decay × eta × batch, tổng 1.120 cấu hình;
MF theo mã iDCF có 10 cấu hình LR × weight decay. `tune --quick` chỉ chạy baseline
để kiểm tra pipeline. Chọn cấu hình bằng validation trước khi chấm test.

CDR gộp cặp train lặp bằng **mean label** để mỗi cặp observed có một trọng số;
điều này tương đương BCE kỳ vọng thực nghiệm theo cặp. Cách gộp nhãn ranking
validation/test vẫn là any-positive. Metadata ghi policy, số cặp, hash dữ liệu thực train,
ESS propensity và tỷ lệ filter riêng observed/direct theo epoch.

CDR huấn luyện từ đầu, không nạp checkpoint MF. Backbone là tích vô hướng không bias,
khởi tạo Xavier normal. Coat: dim 4, LR .05, batch 128, wd .001; KuaiRand: dim 4,
LR .05, batch 2048, wd .0001 (tham khảo script tác giả). Adam giữ LR cố định,
không scheduler, không cap inverse propensity. `unobserved` ở API trainer loại mọi exposure
train, cả dương và âm, với chuẩn hóa riêng cho phần catalog chưa quan sát.
Các thay đổi objective, backbone, cap, scheduler hoặc warm-start cần chọn
`training_profile=experimental` tường minh. Hai lựa chọn `ips_weighting=author/dr` là estimator lịch sử để ablation;
`cdr-author`/`cdr-tune` vẫn là workflow port mã tác giả riêng.
IViDR hiện là **IViDR-approx**, chưa học hệ số bằng MLP theo Eq. (8) của bài báo;
bị loại khỏi `--model all` và `coat-seeds` mặc định. Chạy tường minh `--model ividr`
chỉ để nghiên cứu bản xấp xỉ. [Đối chiếu từng mô hình với nguồn](docs/benchmarks/paper_model_alignment.md).

## Giao thức và kết quả

Train giữ nhãn dương/âm đã exposure; unknown pairs không tự thành negative.
Coat positive khi rating ≥4; KuaiRand dùng `is_click`. Random log chia user 30/70
validation/test, seed 1234. Chỉ xếp hạng logged candidates, gộp cặp lặp bằng any-positive;
NDCG@5/Recall@5 macro loại user không positive. Recall chia toàn bộ positive.
AUC là chỉ số phụ theo user có hai lớp. Coat giữ overlap train/random và công bố số lượng.

Chọn epoch/config bằng validation, sau đó mới chấm test. Checkpoint v4 ghi
`metric_revision=logged_binary_v1`, source/data hash, cấu hình và môi trường;
checkpoint thiếu revision phù hợp bị từ chối. Báo mean ± sample std nhiều seed;
CI theo user của một lượt chạy không thay thế biến thiên seed.

Sau sửa 19/10/2026, cần chạy benchmark mới để kết luận chất lượng, đặc biệt iVAE và CDR
đã đổi cách chọn checkpoint. [Review và trạng thái sửa lỗi](docs/benchmarks/review_2026-10-19.md)
phân biệt số lịch sử với source hiện tại.

## API TopTop

[`src/api/`](src/api/) huấn luyện MF/CDR trên tương tác TopTop, dùng popularity cho
user mới. [Hướng dẫn API và Colab](docs/api/colab_api_guide.md).

```powershell
.\venv\Scripts\python.exe -m uvicorn src.api.app:app --port 8000
```
