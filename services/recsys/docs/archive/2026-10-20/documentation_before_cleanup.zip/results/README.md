# Kết quả và phiên bản thí nghiệm

Theo [cấu hình mô hình cập nhật 20/10](../docs/benchmarks/paper_model_alignment.md),
CDR huấn luyện độc lập từ đầu; MF/iDCF chuyển sang khởi tạo uniform của tác giả.
Các artifact warm-start bên dưới không đại diện CDR nguyên bản.

[`cdr_paper_method_validation_37b126f2c13fcea9.json`](cdr_paper_method_validation_37b126f2c13fcea9.json)
kiểm tra CDR huấn luyện từ đầu với backbone không bias, không cap/scheduler;
seed 42/43/44 chọn epoch 6/7/17. Chỉ chấm validation của ba lượt này, chưa tuning
và chưa chấm test. Artifact cũng ghi smoke thành công MF/iDCF/CDR trên hai dataset;
điểm smoke không được gộp vào kết quả chất lượng.

Các artifact `benchmark_*`, `coat_seeds_*` và tuning cũ là **kết quả lịch sử trước sửa 19/10/2026**.
Không đổi nhãn phiên bản hoặc coi đây là số của source đã sửa. Smoke và regression
test xác minh vận hành, không phải benchmark chất lượng đầy đủ mới.

`cdr_eq7_validation_*.json` ghi thử nghiệm **chỉ validation** của bản Eq. (7), ngày
20/10/2026; có seed, cấu hình, hash và lịch sử filter. Không gộp điểm validation này
với bảng test lịch sử hoặc coi đó là kết quả tái lập paper.

Lượt [20/10, ba seed Coat](cdr_eq7_validation_6346597634257fd0.json): loss hữu hạn,
lọc khoảng 37–41% imputation; cả ba vẫn chọn warm-start epoch 0.
Chưa có cải thiện validation từ fine-tune và chưa chấm held-out test cho lượt này.

| Artifact | Cách sử dụng |
| :-- | :-- |
| `coat_seeds_c25da453e8909e5b` | MF-MSE và IViDR joint/CDR cũ, 10 seed |
| `coat_seeds_7d37e1975c96a410` | iDCF và IViDR-staged; IViDR vẫn có lỗi alpha_residual=1 |
| `coat_seeds_7ae4942b7c4a9f32` | CDR trước khi có lựa chọn warm-start epoch 0 |
| `benchmark_kuairand_all_32e6ded9ad_v4` | Một seed, MF-MSE; IViDR là bản joint đã gỡ |
| `cdr_idcf_tune_coat.json` | Port CDR tác giả, tuning theo giao thức dự án |
| `cdr_author_protocol_coat_thr3.json` | Giao thức CDR tác giả; không so trực tiếp với benchmark dự án |

Các `benchmark_*_v4` và `tuning_*` còn lại cần đọc metadata/source hash để biết
cấu hình thực tế, không chọn chỉ theo tên file hoặc thời gian cập nhật.
Chi tiết: [giao thức](../docs/benchmarks/evaluation_protocol.md),
[trạng thái mô hình](../docs/benchmarks/root_cause_analysis.md),
[review và sửa lỗi](../docs/benchmarks/review_2026-10-19.md).

Chạy lại từ `services/recsys`:

```powershell
.\venv\Scripts\python.exe experiments\run.py coat-seeds
.\venv\Scripts\python.exe experiments\run.py benchmark --dataset kuairand --model idcf
```

Report mới có hash source/data/config riêng. `clean` chỉ xem trước;
`clean --apply` dọn checkpoint, log và bytecode, giữ báo cáo trong thư mục này.
