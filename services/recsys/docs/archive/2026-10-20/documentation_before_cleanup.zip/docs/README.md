# Tài liệu RecSys

Hướng dẫn chạy: [README dịch vụ](../README.md). Kết quả có artifact:
[results/README.md](../results/README.md).

| Tài liệu | Nội dung |
| :-- | :-- |
| [Giao thức đánh giá](benchmarks/evaluation_protocol.md) | Dữ liệu, candidate pool, metric, validation/test và seed |
| [Đối chiếu mô hình với paper](benchmarks/paper_model_alignment.md) | Loss, backbone, khởi tạo, phạm vi chuẩn hóa và phần còn thiếu |
| [Phân tích mô hình](benchmarks/root_cause_analysis.md) | Trạng thái hiện tại và nguyên nhân của kết quả cũ |
| [Review và các sửa lỗi 19/10/2026](benchmarks/review_2026-10-19.md) | Phát hiện R1–R7, trạng thái sửa và hướng thí nghiệm tiếp |
| [Tham chiếu bài báo](benchmarks/paper_reference_comparison.md) | Điểm công bố và điều kiện so sánh |
| [MF và optimizer](benchmarks/mf_optimizer_audit.md) | Phân biệt kiến trúc, loss, khởi tạo và Adam/SGD |
| [API TopTop / Colab](api/colab_api_guide.md) | Nguồn dữ liệu, endpoint và cách chạy |

Tài liệu phục vụ đồ án:

- [Đề cương tổng hợp](de_cuong/DeCuong_NghienCuuUngDungHocMayDeXuatVideoNgan.md).
- [Phần lọc cộng tác](de_cuong/DeCuong_Phan1_LocCongTac_CF.md),
  [phần học sâu](de_cuong/DeCuong_Phan2_HocSau_DeepLearning.md).
- [Slide](presentation/presentation_slides.md), [kịch bản thuyết trình](presentation/presentation_script.md).
- [PDF gốc](papers/), [bản chép/tóm tắt bài báo](paper_summaries/).

Ngày 19/10/2026 đã gỡ kế hoạch API cũ, kế hoạch benchmark v2, nhật ký tuning
KuaiRand 29/09 và hướng dẫn `table3` của kiến trúc joint đã bị gỡ.
Các hướng dẫn vận hành hiện hành nằm ở README dịch vụ và API guide.
Các số trong tài liệu thuyết trình/đề cương cần đối chiếu phiên bản artifact trước khi dùng.
