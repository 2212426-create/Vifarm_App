# PDF nghiên cứu tham khảo

Các PDF được bảo toàn byte và checksum; không phải kết quả mô hình của dự án:

- [iDCF](iDCF.pdf).
- [CDR](CDR.pdf).
- [IViDR](IViDR.pdf).
- [ReCRec](ReCRec.pdf).
- [EGMN](EGMN.pdf): arXiv 2508.12665v2, 10 trang; paper EGMN RecSys 2025.
- [LDRI](LDRI.pdf): arXiv 2408.17332v1, 10 trang; bài liên quan đến release-interval bias,
  **khác paper CRIB**.

PDF toàn văn CRIB chưa tải được từ nguồn hợp lệ có thể truy cập: publisher/API PDF
trả 403/406/401, XML chỉ có metadata. Không có file `CRIB.pdf` giả hoặc PDF của bài khác
được đặt tên thay thế. Xem [hồ sơ MF-CRIB](../paper_summaries/MF_CRIB.md) và
[manifest tải tài liệu, tiêu đề và SHA-256](short_video_downloads_20261022.json).

Đối chiếu [bản chép](../paper_summaries/README.md) khi đọc nhanh, kiểm tra lại PDF
trước khi trích công thức/bảng. Tình trạng triển khai: [CURRENT_STATE](../CURRENT_STATE.md).
Checksum giữ nguyên file đang lưu, không chứng nhận rằng nó là phiên bản xuất bản mới nhất.
