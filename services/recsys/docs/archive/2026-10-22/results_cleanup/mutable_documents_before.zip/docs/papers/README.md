# PDF nghiên cứu tham khảo

Các PDF được bảo toàn byte và checksum; không phải kết quả mô hình của dự án:

- [iDCF](iDCF.pdf).
- [CDR](CDR.pdf).
- [IViDR](IViDR.pdf).
- [ReCRec](ReCRec.pdf).

Đối chiếu [bản chép](../paper_summaries/README.md) khi đọc nhanh, kiểm tra lại PDF
trước khi trích công thức/bảng. Tình trạng triển khai: [CURRENT_STATE](../CURRENT_STATE.md).
Checksum giữ nguyên file đang lưu, không chứng nhận rằng nó là phiên bản xuất bản mới nhất.
