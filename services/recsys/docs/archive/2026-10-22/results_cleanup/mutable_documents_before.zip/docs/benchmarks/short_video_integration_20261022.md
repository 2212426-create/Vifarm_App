# MF-CRIB và EGMN trong RecSys

Hai mô hình đã có implementation, loader, training/evaluation, checkpoint và lệnh CLI.
Điểm bắt đầu đọc trạng thái: [CURRENT_STATE](../CURRENT_STATE.md).
Đây là tích hợp source tác giả có các điều chỉnh công khai, chưa chứng nhận tái lập điểm paper.

## Chạy từ services/recsys

Chạy thử cả hai trên subset 64 user có mặt ở ba split thời gian của KuaiRand-Pure:

```powershell
.\venv\Scripts\python.exe experiments\run.py short-video --smoke --threads 2
```

Chạy cả hai trên toàn bộ dữ liệu có sẵn, ngân sách mặc định MF-CRIB 20 epoch,
EGMN 10 epoch; CPU có thể mất nhiều thời gian:

```powershell
.\venv\Scripts\python.exe experiments\run.py short-video --dataset kuairand --threads 2
```

Chạy riêng hoặc thử toàn dữ liệu với ngân sách ngắn:

```powershell
.\venv\Scripts\python.exe experiments\run.py mf-crib --dataset kuairand --threads 2
.\venv\Scripts\python.exe experiments\run.py egmn --dataset kuairand --threads 2
.\venv\Scripts\python.exe experiments\run.py short-video --epochs 1 --threads 2
```

`--smoke` giới hạn user và mặc định 1 epoch; `--epochs 1` riêng chỉ giới hạn epoch,
vẫn dùng toàn dữ liệu. Cả hai là kiểm tra vận hành, không dùng điểm để kết luận paper.
`--data-dir` nhận thư mục KuaiRand-Pure hoặc thư mục `data/` con chứa các CSV.
Coat/Yahoo không có upload/watch-time cần thiết nên hai lệnh không nhận các dataset này.
Không cần cài thêm dependency ngoài requirements hiện hành cho các đường chạy đã tích hợp.

Mỗi lượt tạo JSON mới trong `results/`, trọng số riêng trong `checkpoints/short_video/`.
JSON ghi config, protocol, source hash, commit nguồn, checksum dữ liệu gốc/đầu vào đã xử lý,
history validation và metric test. Nạp lại để chấm, dùng đúng subset/dữ liệu của lượt gốc:

```powershell
.\venv\Scripts\python.exe experiments\run.py mf-crib --checkpoint "DUONG_DAN_MODEL_PT" --smoke
.\venv\Scripts\python.exe experiments\run.py egmn --checkpoint "DUONG_DAN_MODEL_PT" --smoke
```

Với checkpoint toàn dữ liệu, bỏ `--smoke`. Nếu trước đó dùng `--smoke-users` khác 64
hoặc data-dir riêng, truyền lại chúng; CLI kiểm tra data/protocol identity trước đánh giá.
Seed mặc định được lấy từ checkpoint khi nạp lại; JSON vẫn giữ hash huấn luyện gốc,
và ghi riêng hash mã đánh giá. Không dùng `evaluate` của bộ bốn cho hai kiến trúc mới.

## MF-CRIB

Paper: [Beyond the latest: Correcting Release Interval Bias in short-video recommendation](https://doi.org/10.1016/j.knosys.2026.116486).
Source khóa [A-Egoist/CRIB, ff92ec91](https://github.com/A-Egoist/CRIB/tree/ff92ec91a2bf6cf66eecd6fc1b9d0f1f61d0b226).
[Hồ sơ nguồn](../../src/models/mf_crib/source.json),
[source nguyên byte](../../third_party/crib/upstream_manifest.json),
[mô hình](../../src/models/mf_crib/released.py),
[adapter](../../src/models/mf_crib/adapter.py), [training](../../src/models/mf_crib/train.py).

- Giữ bốn bảng embedding user/item và user/item-time, MLP extrapolate trend
  20 → 32 → 10, ReLU và dropout .5. Hàm prediction và regularizer giữ theo source.
- Loss: BCE(global score, label) + BCE(time score, label) + lambda × regularizer.
  Adam; dim 16, LR .0001, lambda .1, alpha .4, batch 2048, seed 2000.
  Alpha .4 theo parser/bảng KuaiRand-Pure; ví dụ README .5 không dùng làm mặc định.
- Nhãn: OR(click, like, comment, follow, forward, profile-enter) AND NOT hate.
  Hai standard log; không dùng random log. Split theo ngày 08–28/04 train,
  29/04–01/05 validation, 02–08/05/2022 test, theo code preprocessing.
- Trend chỉ lấy exposure train. Theo source, trend rộng 20 bỏ cột capped day-20;
  global trend lấy các bin đã quan sát rồi interpolate; test interval được đóng băng
  ở ngày 01/05. Không diễn giải `time_diff` như đang được score trực tiếp: forward
  của tác giả nhận tham số này nhưng không dùng nó trong phép tính score.
- Giữ mặc định lấy trọng số cuối; kiểm tra stopping ở epoch 6/11/16… như lịch zero-based
  của tác giả, patience 2, cải thiện một trong Recall/NDCG source @10 là reset counter.
  Validation mỗi epoch còn lại chỉ là diagnostic. `--selection best-validation` là
  lựa chọn địa phương tường minh theo NDCG source @10, không phải default source.

Điều chỉnh vận hành: register trend thành buffer để `.to(device)`/checkpoint đúng;
DataLoader Windows dùng 0 worker; không shuffle validation (source main có shuffle
nhưng gán dự đoán trở lại DataFrame theo thứ tự cũ, gây lệch dòng); chỉ loại null ở
cột bắt buộc thay vì cột raw không sử dụng. Vì vậy không nhận là quỹ đạo training
hoàn toàn giống script tác giả, dù toán mô hình/loss đã kiểm tra khớp từng bước.

Metric source `NDCG@k_source` dùng DCG / (IDCG trên **toàn positive row** + 1),
không phải NDCG chuẩn. `Recall@k_source` chia số positive row, có thể khác số item duy nhất.
Giữ điểm source được làm tròn 4 chữ số theo code. JSON có thêm NDCG chuẩn,
Recall/all positives và Recall bounded trên item đã gộp; các tên không thay thế nhau.
Đầu ra hiển thị có bounded theo lựa chọn của người dùng; so paper phải dùng đúng metric/protocol.

## EGMN

Paper: [RecSys 2025, arXiv 2508.12665v2](https://arxiv.org/html/2508.12665v2),
DOI [10.1145/3705328.3748080](https://doi.org/10.1145/3705328.3748080).
Source khóa [BestActionNow/EGMN, 162b09bd](https://github.com/BestActionNow/EGMN/tree/162b09bda15ef57e3abb1d56eff5f046825eae5c).
[Hồ sơ nguồn](../../src/models/egmn/source.json),
[source nguyên byte](../../third_party/egmn/upstream_manifest.json),
[mô hình](../../src/models/egmn/model.py), [training](../../src/models/egmn/train.py).

Giữ nguyên code model/loss, chỉ đổi import `model.layers` sang import tương đối.
Một exponential + 10 Gaussian, mean Gaussian = 1/rate + softplus; MLP dùng BatchNorm,
ReLU/dropout; embedding 16, shared layers 256/128/64, dropout .2.
NLL + .1 × entropy + 1 × L1 regression; Adagrad LR .1, weight decay 1e-6, seed 42,
batch 2048, 10 epoch, mặc định lấy trọng số epoch cuối. Source code dùng likelihood
Gaussian truncate trái tại 0 và sigma làm scale, còn prediction dùng mean chưa hiệu chỉnh
truncation. Giữ khác biệt paper/source này rõ ràng thay vì tự đổi công thức.

Loader KuaiRand là **adaptation**, protocol `egmn_kuairand_watch_time_temporal_v1`:

- Nhãn watch time liên tục, không đổi thành click/BCE/MSE. Giữ exposure có
  0 < play_time_ms < 10 × duration_ms, duration > 0, loại video AD.
- Split thời gian như trên; normalization bằng max play_time của **train**;
  vocabulary học trên train, OOV index 0. Thời gian test có thể vượt 1 sau normalization.
- Feature có sẵn: user/video/author/type/music/tag và duration; khác tập feature
  KuaiRec của tác giả. Chưa dùng caption category hoặc duration qcut từ nguồn KuaiRec.
- DataLoader giữ thứ tự source, không shuffle; nếu batch cuối chỉ có một dòng,
  gộp vào batch trước cho BatchNorm, không bỏ hoặc lặp mẫu.
- Mặc định epoch cuối như runner source; `--selection best-validation` dùng MAE validation,
  là adaptation được ghi trong metadata. Test chấm sau training/selection.

MAE được báo cả normalized và **giây**, dùng scale thực tế của lượt xử lý dữ liệu.
`XAUC_source` giữ denominator mọi cặp/tie convention của source.
`KL_source` dùng histogram trên miền nhãn, bỏ prediction ngoài miền như code gốc;
nếu tất cả prediction nằm ngoài thì trả null với lý do, không gán 0.
`KL_common_support` bổ sung dùng miền chung nhãn/prediction để giữ toàn bộ xác suất.
Không so trực tiếp các metric watch-time này với NDCG click của bộ bốn.

Có thể nạp pickle KuaiRec **đã xử lý cục bộ** đúng cấu trúc tác giả:

```powershell
.\venv\Scripts\python.exe experiments\run.py egmn --dataset kuairec --processed-path "data\processed\kuairec\kuairec_data.pkl" --watch-time-scale-ms 999639 --threads 2
```

Pickle cần `train`, `test` là DataFrame, `description` chứa các tuple (tên, size, type).
`play_time`, `duration`, feature/mask phải đã được xử lý bởi script nguồn.
Type hỗ trợ spr/seq/ctn/seqm/label như source; `feat` sequence đi cùng `featmask`.
Không có validation thì chỉ dùng `source-final`; không chia test để chọn checkpoint.
Scale 999639 ms là hằng của runner nguồn; truyền **max thực tế của preprocessing**,
hoặc thêm `watch_time_scale_ms` trong pickle. Đã kiểm tra loader bằng fixture;
chưa có dữ liệu KuaiRec thật trong workspace để xác minh chất lượng/tái lập paper.

## Nguồn, kiểm chứng và giới hạn

`third_party/` giữ các file tham chiếu đúng byte và manifest SHA-256; package `src/models/`
giữ code chạy/adapter. Không cài dgl, sklearn, matplotlib, loguru từ toàn bộ repo vì
đường chạy đã tích hợp không cần chúng. Cả hai tree tại commit khóa chưa cung cấp LICENSE;
giữ attribution và trạng thái này trong hồ sơ nguồn, không tự gán giấy phép cho mã tác giả.

[Kiểm thử](../../tests/test_short_video_models.py) đối chiếu prediction, loss và ba bước
Adam/Adagrad với lớp nguồn; kiểm tra interval/nhãn, train-only normalization/vocabulary,
metric khác định nghĩa, batch singleton, checkpoint roundtrip và chặn mismatch dữ liệu.
[Bằng chứng tích hợp](../../results/short_video_integration_verification_20261022.json)
ghi source hash và các lượt chạy có thật. Kết quả trước hoàn thiện source giữ hash cũ;
không dùng smoke hoặc full-data 1 epoch làm kết quả paper/default 20/10 epoch.

CLI `benchmark --model all` vẫn phục vụ bốn mô hình và protocol đã chốt;
CLI `short-video --model all` chạy hai mô hình mới theo hai mục tiêu riêng.
Không đổi loss, dữ liệu, checkpoint hoặc số liệu của bốn mô hình cũ trong đợt này.
