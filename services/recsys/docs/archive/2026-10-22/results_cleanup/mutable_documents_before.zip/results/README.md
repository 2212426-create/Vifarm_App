# Kết quả RecSys: đọc metadata trước khi trích số

**Chỉ dẫn từng artifact: [CATALOG.md](CATALOG.md).**
Trạng thái triển khai hiện tại ở [CURRENT_STATE](../docs/CURRENT_STATE.md).
Một tên `v4` không xác định loss/backbone/source; thời gian sửa file cũng không
xác nhận kết quả thuộc mô hình hiện hành.

Mốc hiện hành **bảng chỉ giữ Recall@5 bounded**, 21/10/2026:
[Markdown](benchmark_report_bounded_20261021_074350_e29d0387.md),
[JSON](benchmark_report_bounded_20261021_074350_e29d0387.json).
Chỉ đổi cột hiển thị; JSON giữ cả hai Recall cùng mọi giá trị gốc. Không retrain.

Mốc trước **bảng gộp đầy đủ metric**, 21/10/2026:
[Markdown](benchmark_report_20261021_072543_c37b107c.md),
[JSON](benchmark_report_20261021_072543_c37b107c.json),
[kiểm chứng](complete_metrics_report_verification_20261021.json).
Tính lại metric bổ sung từ checkpoint CDR, không retrain; giữ nguyên sáu dòng
MF/iDCF và điểm gốc CDR. Bảng có hai Recall, Precision/HitRate, protocol và loại AUC.
Không coi việc gộp hiển thị là cùng điều kiện so sánh thực nghiệm.

Mốc trước **đồng nhất log huấn luyện** có
[biên bản kiểm chứng](unified_training_logs_verification_20261020.json),
115 test (114 đạt, 1 bỏ qua), smoke MF/iDCF/CDR và CDR Coat đầy đủ giữ nguyên điểm.
Source protocol, loss, seed, metric và lựa chọn checkpoint không đổi.

Mốc trước đổi log **CDR source protocol mặc định** có
[biên bản kiểm chứng](cdr_source_default_verification_20261020.json),
Coat benchmark NDCG .656665 / Recall bounded .667816 / AUC .751293;
Yahoo source đầy đủ .655929 / .731299 / .684930. Giữ đúng metric/protocol nguồn,
không gọi là held-out độc lập hoặc so trực tiếp với MF/iDCF giao thức khác.
KuaiRand/API đã dùng released estimator với adaptation có metadata.

Mốc trước tích hợp Yahoo và CDR released trên giao thức chung có
[biên bản kiểm chứng](yahoo_source_integration_verification_20261020.json),
smoke ba dataset, lượt Yahoo toàn dữ liệu ngân sách ngắn, validation CDR ba seed
và đối chứng script Coat. Chưa có benchmark chất lượng đầy đủ ba mô hình Yahoo.
Các artifact được dẫn rõ trong [CATALOG](CATALOG.md).

Trước tích hợp released, sau sửa pipeline Coat đã có
[benchmark test đầy đủ, seed 42](benchmark_coat_all_16747d3add_20261020_194738_4bb0b674_v4.md),
[validation ba seed](coat_pipeline_fix_validation_20261020.json) và
[audit CDR theo mã công bố](cdr_followup_audit_20261020.json).
Diagnostic theo script gốc có dùng nhãn random chấm điểm cho propensity, không
dùng điểm đó thay cho benchmark held-out. Các lượt smoke chỉ xác nhận vận hành.

Lượt **Coat đầy đủ trước sửa pipeline**, source `36230d1cd908`, seed 42:
[báo cáo](coat_full_20261020_185436_60df72/benchmark_coat_all_429e263db0_v4.md),
[JSON](coat_full_20261020_185436_60df72/benchmark_coat_all_429e263db0_v4.json).
Đã chọn checkpoint bằng validation và chấm held-out test; chưa tuning, chưa nhiều seed.
Checkpoint/log/report được lưu riêng, không ghi đè artifact cũ.

Hai artifact validation trước sửa ngày 20/10 có phạm vi khác nhau:

| Artifact | Trạng thái |
| :-- | :-- |
| [cdr_paper_method_validation_37b126f2c13fcea9.json](cdr_paper_method_validation_37b126f2c13fcea9.json) | CDR huấn luyện độc lập; ba seed, chỉ validation, chưa tuning/test; có ghi riêng smoke hai dataset |
| [cdr_eq7_validation_6346597634257fd0.json](cdr_eq7_validation_6346597634257fd0.json) | Ablation warm-start đã bị thay thế; cả ba seed chọn MF epoch 0; không đại diện CDR độc lập |

Các artifact trong nhóm **lịch sử** của CATALOG có source khác mốc hiện hành.
Không tự gán ngày chạy cho cả nhóm khi artifact
không ghi ngày; không gọi chúng là kết quả mới chỉ vì cùng tên mô hình.
Port `cdr-author` và lượt `cdr_idcf_tune` là các đường chạy chẩn đoán riêng.

## Giữ nguyên dấu vết

- JSON/Markdown kết quả và evidence giữ nguyên byte; checksum trong
  [docs/catalog.json](../docs/catalog.json).
- Đính chính đặt trong tài liệu hiện hành/catalog, không sửa lại số hoặc metadata cũ.
- Lượt chạy mới dùng artifact khác; không ghi đè đường dẫn cũ hoặc đổi hash cho khớp code mới.
- Kiểm chứng `python docs/check_docs.py`; đọc source/data/config/metric và split
  trước khi trích số từ bất kỳ artifact nào.

`clean --apply` dọn checkpoint, log, bytecode, giữ báo cáo. Nó không tạo lại bằng
chứng của một checkpoint đã xóa. Smoke không dùng thay benchmark chất lượng.
