# Trạng thái RecSys hiện hành

Mốc **21/10/2026: MF + CDR + iDCF + IViDR-BCE**. IViDR đã thay lõi staged
bằng learned IV, dual iVAE và feedback BCE theo công thức arXiv; các lựa chọn
địa phương và giới hạn tái lập được ghi trong [hướng dẫn IViDR](benchmarks/ividr_bce_20261021.md).
MF/iDCF giữ MSE; CDR source protocol giữ nguyên. Chưa xác nhận tái lập bản ACM.

Người dùng đã chốt giữ BCE theo Eq. (25), hủy chuyển feedback sang MSE.
Source hiện hành chỉ còn khác mốc chạy BCE ở docstring của pipeline lịch sử:
`017c3601e4f3744c42e95e2eecaad571a761178b8c315d65cb31201f19591b39`.
Code training, workflow và test đã khôi phục nguyên byte; không huấn luyện mới
hoặc gán lại điểm từ mốc `70897b831d4f` sang source mới.
**126 test: 125 đạt, 1 CUDA skip**; smoke đủ bốn mô hình trên ba dataset;
smoke là bằng chứng ở mốc BCE trước. CDR validation ba seed đã chạy lại trên
source hiện hành. [Xác nhận mặc định](../results/paper_default_confirmation_20261021.json)
· [Validation](../results/paper_default_confirmation_validation_20261021.json).

<!-- source-cleanup-status:start -->
Cleanup completed at the explicit request of the user; rejected-source material and its backups removed. See results/source_cleanup_completion_20261021.json.
<!-- source-cleanup-status:end -->

[Chạy đầy đủ Coat](../results/benchmark_coat_all_b384ff80db_20261021_115348_e8c7d044_v4.md):
NDCG MF .547612, iDCF .569884, IViDR-BCE .529125, CDR .656665;
Recall bounded .584032 / .602295 / .590419 / .667816. MF/iDCF/CDR khớp
chính xác metric và mọi tensor mốc trước. IViDR chọn LR/WD bằng validation,
chỉ đánh giá checkpoint thắng trên test.

[Ablation MSE/BCE](../results/ividr_mse_bce_ablation_20261021.json), Coat seed 42:
cùng latent và LR/WD, MSE NDCG .540521 / bounded .603493, BCE .529125 / .590419.
Nếu từng loss chọn cấu hình theo validation, MSE .516317 / .594711;
BCE .529125 / .590419. Đây là một seed, chưa kết luận loss nào luôn tốt hơn;
không dùng test để đổi mặc định BCE theo paper.

## Mốc lịch sử: bộ bốn trước khi sửa IViDR theo paper

Mốc trước **21/10/2026: bộ bốn MF + CDR + iDCF + IViDR-approx**.
[Snapshot](state_snapshot.json) · [Lệnh chạy](../README.md) ·
[Định nghĩa](benchmarks/paper_model_alignment.md) · [Giao thức](benchmarks/evaluation_protocol.md).

Source đã kiểm chứng:
`4ca654f49942424708c3fd56fcfa9f8c939702831b59d4781bf168c5f2ceb883`.

Người dùng giữ cả iDCF và thêm IViDR vào bộ chạy. Tại mốc này lõi staged
địa phương hiển thị **IViDR-approx**, chưa đọc được bản ACM cuối do HTTP 403.
Triển khai hiện hành xem [hướng dẫn IViDR-BCE](benchmarks/ividr_bce_20261021.md).

**Đã chạy đầy đủ bốn mô hình trên Coat**: NDCG MF .547612, iDCF .569884,
IViDR-approx .532193, CDR .656665. Recall bounded tương ứng .584032 / .602295 /
.557884 / .667816. MF/iDCF/CDR giữ chính xác metric và mọi tensor trọng số
so với lượt trước. [Báo cáo](../results/benchmark_coat_all_e052d60c74_20261021_095855_83a07811_v4.md)
· [Biên bản](../results/four_model_default_verification_20261021.json).
Training source 35e5fcf0d0bd; sau đó chỉ sửa câu mô tả IViDR trong coat-seeds,
không gán lại source hash cũ. Source cuối đã qua **119 test: 118 đạt, 1 CUDA skip**;
smoke đủ 4 mô hình trên ba dataset và CDR validation ba seed khớp mốc trước.
[Validation cuối](../results/four_model_default_final_validation_20261021.json).
Mặc định `benchmark --model all`, `smoke` và `coat-seeds` có bốn mô hình;
bảng đủ 12 dòng nếu chạy cả ba dataset, chỉ hiển thị Recall bounded.

## Mốc hiển thị trước khi thêm IViDR

Theo lựa chọn người dùng, bảng chỉ giữ Recall@5 bounded, ghi rõ tên cột.
Hai Recall và mọi metric vẫn nguyên trong JSON; không đổi training/evaluation.
[Báo cáo cũ ba mô hình](../results/benchmark_report_bounded_20261021_074350_e29d0387.md)
được dựng lại từ JSON có sẵn, không retrain hoặc tính lại metric.
[Kiểm chứng mốc hiển thị](../results/bounded_recall_display_verification_20261021.json).
Training source 134b536cc623, evaluation source 324556887803, render source 6497b9eefd64.

**Đã chạy lại đầy đủ ba mô hình Coat ở mốc 6497b9eefd64**, CPU 2 thread:
MF NDCG .547612 / Recall bounded .584032; iDCF .569884 / .602295;
CDR .656665 / .667816. Điểm gốc, epoch chọn và mọi tensor trọng số khớp chính xác
lượt trước. [Báo cáo mới](../results/benchmark_coat_all_666cb1327c_20261021_074841_a3d6e730_v4.md)
· [Đối chiếu checkpoint](../results/coat_reproducibility_20261021_074841.json).
Đây là kiểm chứng lặp lại cùng seed, không phải seed độc lập hoặc tuning.

CDR bổ sung cả Recall/all positives và Recall bounded, Precision/HitRate từ
cùng ranking/user cohort, giữ nguyên metric nguồn. S-full empty-positive vẫn
có Recall=1; Precision/HitRate=0. Bảng ở mốc cũ có 9 dòng với protocol và
loại AUC; không paired-test chéo protocol. Không đổi training hoặc checkpoint.

[Báo cáo trước khi ẩn Recall/all positives](../results/benchmark_report_20261021_072543_c37b107c.md)
được tính từ checkpoint, không retrain; giữ nguyên sáu dòng MF/iDCF và metric gốc
của CDR. JSON giữ training source 134b536cc623 và evaluation source mới riêng biệt.
[Biên bản kiểm chứng](../results/complete_metrics_report_verification_20261021.json).

Log dùng chung tiêu đề cấu hình, prefix model/dataset, tiến độ epoch, kết thúc
và checkpoint. iDCF hiển thị cả iVAE (train/val ELBO, beta, warm-up/full-beta)
và feedback (train loss, validation ranking). CDR source ghi rec/imp loss từng
epoch rồi SOURCE EVAL cuối lượt; không tự thêm validation hoặc đổi cơ chế dừng.
Không thay đổi loss, seed, split, metric, optimizer hay lựa chọn checkpoint.

## Mặc định đang chạy

- CDR benchmark Coat/Yahoo dùng cùng hàm `run_source` với `cdr-source`:
  seed 2020, dim 4, trần 1000 epoch, dừng theo train loss và lấy trọng số cuối.
  Nhãn >=3; calibration bằng 5% nhãn random chấm điểm; đánh giá toàn random log,
  zero-positive nhận 1, Recall bounded và AUC toàn cục.
- Lệnh `benchmark --dataset coat --model cdr` đã chạy đầy đủ:
  **NDCG .6566651228 / Recall bounded .6678160920 / AUC .7512927651**.
  [Báo cáo sau đổi log](../results/benchmark_coat_cdr_dd41848bc6_20261020_231233_64456c33_v4.md).
  Khớp lượt cdr-source người dùng xác nhận; không gọi đây là test độc lập chưa dùng nhãn calibration.
  [Yahoo source đầy đủ trước đổi log, source abc819e34351](../results/cdr_source_yahoo_20261020_225246_193982ea.json):
  NDCG .655929 / Recall bounded .731299 / AUC global .684930; không gán lại số paper.
- MF/iDCF/IViDR-approx giữ MSE, >=4, random-log user split 30/70 và checkpoint validation.
  Bảng gộp ghi protocol và loại AUC từng dòng; không kiểm định chéo với MF/iDCF khác protocol.
- KuaiRand đã chuyển sang thuật toán CDR released. Dữ liệu vẫn là preprocessing
  địa phương; calibration 5% validation; array sampling thay DataLoader; catalog
  lớn dùng sampling có hoàn lại để giới hạn RAM. Không tuyên bố tái lập chính xác script KuaiRand.
- API đã dùng ReleasedCDR 4 chiều, variance filter, output dropout và source
  update/loss. App không có random log nên giữ propensity item-frequency và
  sampling có hoàn lại, ghi trong training_stats.cdr. Ngân sách phục vụ riêng.
- Tuning Coat/KuaiRand dùng estimator released, trần 1000, seed 2020,
  train-loss stopping/lấy trọng số cuối, calibration 5% validation. Chọn cấu hình
  bằng validation; không dùng nhãn test để tune. Đây là tuning adaptation,
  không phải cách lấy điểm source protocol. Coat CDR tuning dùng >=3, MF >=4.
- `coat-seeds` dùng source protocol cho CDR; checkpoint được giữ lại.
  Recall được gắn đúng tên bounded, không Wilcoxon chéo protocol.
- `cdr-author` là alias `cdr-source`; `cdr-tune` alias tuning released.
  Bản Eq. (7) cũ chỉ chạy tường minh qua `--cdr-implementation equation` hoặc
  hàm legacy; giữ để đọc checkpoint/ablation. `--cdr-implementation shared`
  dùng released với giao thức held-out chung.

## Kiểm chứng mốc hiển thị trước khi thêm IViDR

**118 test: 117 đạt, 1 CUDA bỏ qua**.
[Log](archive/2026-10-21/bounded_recall_display/model_tests.log).
Có kiểm thử 3 epoch CPU khớp từng trọng số lớp gốc, metric source, loại CDR
source khỏi paired tests chung, sampler cho event lặp, API released và dispatch tuning.
Hai test mới xác nhận progress callback không đổi tham số/history/dừng sớm CDR,
latent và checkpoint selection của iVAE.
Ba test mới tính tay cả hai Recall/Precision/HitRate, zero-positive, candidate<k
và bảng 9 dòng có đủ metric thực cùng protocol/loại AUC.

[Biên bản mốc log](../results/unified_training_logs_verification_20261020.json)
dẫn smoke ba mô hình Coat, CDR Coat source đầy đủ và hồi quy validation ba seed.
[Biên bản trước đổi log](../results/cdr_source_default_verification_20261020.json)
giữ kiểm chứng ba dataset, chạy seed, tuning, API và reload tại source abc819e34351.
[Validation-only diagnostic mốc hiển thị](../results/bounded_recall_display_validation_20261021.json)
là phép kiểm tra riêng của estimator với validation, không thay điểm source benchmark.
Ba seed khớp chính xác epoch/điểm validation của mốc trước.
Không coi smoke/quick là kết quả chất lượng.

Python 3.12.10, PyTorch 2.14.1+cpu, NumPy 2.5.4, pandas 3.0.6; CPU 2 thread.
Chưa kiểm chứng CUDA.

## Yahoo và các giới hạn giữ nguyên

Yahoo! R3: 15.400 user, 1.000 item; 311.704 train / 54.000 random ratings;
đã tải từ commit nguồn được chỉ định. MF/iDCF chuyển ID về 0-based; CDR source
giữ ID 1-based/dummy row như script. Train/random overlap bằng 0.

iDCF Yahoo dùng 7 câu survey thật, one-hot 39 chiều; 10.000 user thiếu survey
nhận category thiếu. Đây là adaptation địa phương, chưa phải tái lập pipeline
Yahoo của tác giả; giả định nhân quả ở nhóm thiếu survey chưa được xác minh.
**Đính chính 21/10/2026:** paper iDCF có kết quả Yahoo; mã tác giả chỉ giữ
5.400 user có survey, khác 15.400 user hiện tại. Đã tìm thấy repository chính thức
iDCF. [Biên bản nguồn](benchmarks/source_repository_review_20261021.md).
iVAE Coat/Yahoo 16/32/3, KuaiRand 32/64/2, chọn sau full-beta warm-up.
IViDR-BCE thuộc bộ mặc định theo yêu cầu người dùng;
Yahoo giữ adaptation survey/missing category và chưa tái lập paper.

## Lịch sử

Source trước `88769819bd67` dùng released nhưng calibration/chọn checkpoint theo
giao thức chung; chưa phải mặc định source protocol hiện nay.
[Kiểm chứng cũ](../results/yahoo_source_integration_verification_20261020.json)
giữ nguyên số và hash. CDR Eq. (7) .448514 tại source `d5bdd13e82c3` không phải
điểm của CDR source hiện hành.
[Bản trước thay đổi](archive/2026-10-20/cdr_source_default/before_change.zip).

[Catalog kết quả](../results/CATALOG.md) · [Bảo toàn tài liệu](MAINTENANCE.md).
