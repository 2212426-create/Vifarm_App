# -*- coding: utf-8 -*-
from src.causal.cdr.cdr_model import CDRFramework
from src.causal.cdr.imputation_model import ImputationModel
from src.causal.cdr.dr_bias_loss import dr_bias_closed_form_imputation_loss, cdr_recommendation_loss
from src.causal.cdr.train_dr_bias_cdr import train_dr_bias_cdr
from src.causal.cdr.released import ReleasedCDR


def train_cdr(*args, **kwargs):
    """Default CDR entrypoint: published-source algorithm and protocol."""
    from src.causal.cdr.source_protocol import run_source
    return run_source(*args, **kwargs)

__all__ = [
    "CDRFramework",
    "ReleasedCDR",
    "train_cdr",
    "ImputationModel",
    "dr_bias_closed_form_imputation_loss",
    "cdr_recommendation_loss",
    "train_dr_bias_cdr"
]

