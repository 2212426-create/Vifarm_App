# Catalog kết quả RecSys — mốc 20/10/2026

Phân loại theo nội dung JSON và source hash, không suy ngày chạy từ tên hoặc mtime.
Artifact giữ nguyên byte. Bảng dưới chỉ dẫn cách đọc, không thay metadata và không trộn điểm.
[Trạng thái hiện hành](../docs/CURRENT_STATE.md) · [Checksum](../docs/catalog.json).

## Hiện hành: đồng nhất log huấn luyện

[Biên bản kiểm chứng](unified_training_logs_verification_20261020.json), source
`134b536cc623`: 115 test (114 đạt, 1 CUDA bỏ qua), CDR/iVAE callback giữ nguyên
trọng số/latent và quyết định dừng/chọn checkpoint.
[Smoke ba mô hình Coat](benchmark_coat_all_quick_7e3c020ae1_20261020_231221_e4861999_v4.json)
xác nhận đủ header, epoch, stage iVAE/feedback, TEST/SOURCE EVAL và checkpoint.
[CDR source Coat đầy đủ](benchmark_coat_cdr_dd41848bc6_20261020_231233_64456c33_v4.json)
vẫn đạt NDCG .656665 / Recall bounded .667816 / AUC global .751293.
[Validation diagnostic](unified_training_logs_validation_20261020.json) khớp
chính xác epoch và điểm validation ba seed trước đổi log; chỉ validation.
Đây là thay đổi hiển thị, không chuyển số Yahoo/KuaiRand cũ sang source mới.

## Mốc trước đổi log: CDR source protocol mặc định

[Biên bản kiểm chứng](cdr_source_default_verification_20261020.json), source
`abc819e34351`: 113 test (112 đạt, 1 CUDA bỏ qua), smoke ba dataset,
benchmark mặc định, seed 2020, tuning quick và reload checkpoint source.

- [Benchmark Coat CDR mặc định](benchmark_coat_cdr_a8d27b91f8_20261020_224913_af558386_v4.json)
  · [MD](benchmark_coat_cdr_a8d27b91f8_20261020_224913_af558386_v4.md):
  NDCG .656665 / Recall bounded .667816 / AUC global .751293. Cùng hàm với cdr-source.
- [Yahoo source đầy đủ](cdr_source_yahoo_20261020_225246_193982ea.json):
  NDCG .655929 / Recall bounded .731299 / AUC global .684930.
  Đây là số thực chạy, không thay bằng số paper .6565/.7323/.6912.
- [Coat seed 2020](coat_seeds_73aeaea0873a3298_20261020_224946_b292cb89.json):
  khớp điểm benchmark/source; không phải seed độc lập hoặc độ ổn định nhiều seed.
- [Smoke Coat](benchmark_coat_all_quick_f07c1965db_20261020_224958_c1be1bf7_v4.json),
  [Yahoo](benchmark_yahoo_all_quick_7f2613dc8c_20261020_225005_acf377b2_v4.json),
  [KuaiRand](benchmark_kuairand_all_quick_db610a538f_20261020_225029_401b7143_v4.json):
  chỉ kiểm tra vận hành, CDR có scope dữ liệu/metric riêng; không so chất lượng.
- [Tuning quick](tuning_coat_cdr_e1_a8a81b00f8660f52_ee1f3f4b_v4.json):
  released estimator, 1 epoch, calibration/chọn cấu hình chỉ validation;
  không phải điểm source protocol hoặc lượt tuning hoàn chỉnh.
- [Validation diagnostic](cdr_source_estimator_validation_20261020.json):
  source estimator, ba seed, chỉ validation; không chuyển số sang source benchmark.

Coat/Yahoo source dùng 5% nhãn random chấm điểm cho calibration, >=3, toàn random
log, empty-positive nhận 1, Recall bounded. Báo cáo ở bảng riêng, không paired-test
chéo với MF/iDCF held-out. KuaiRand và API dùng released estimator nhưng có
adaptation dữ liệu/sampler/propensity ghi rõ; không gọi là tái lập toàn bộ script.
Các lượt phát triển trước khi đóng source được giữ nguyên hash, không gán sang mốc này.

## Mốc trước: tích hợp Yahoo và CDR released trên giao thức chung

[Biên bản kiểm chứng](yahoo_source_integration_verification_20261020.json), source
`88769819bd67`: 109 test (108 đạt, 1 CUDA bỏ qua), CDR khớp từng tham số lớp gốc
sau 3 epoch CPU, smoke đủ MF/iDCF/CDR trên Coat, Yahoo và KuaiRand.

- [Yahoo toàn dữ liệu, quick — JSON](benchmark_yahoo_all_quick_5c628bd4b7_20261020_222302_b3d1e0bf_v4.json)
  · [MD](benchmark_yahoo_all_quick_5c628bd4b7_20261020_222302_b3d1e0bf_v4.md):
  1 epoch feedback / 2 epoch iVAE; kiểm tra vận hành, chưa phải benchmark chất lượng.
- [Coat smoke](benchmark_coat_all_quick_f91c57579a_20261020_222119_147e6ae1_v4.json),
  [Yahoo 64 user](benchmark_yahoo_all_quick_73a6598a78_20261020_222127_b44aa7e9_v4.json),
  [KuaiRand 64 user](benchmark_kuairand_all_quick_907333adfb_20261020_222130_447f113a_v4.json):
  cùng mốc source; cấu hình smoke ghi metadata, không dùng so paper.
- [CDR released validation ba seed](released_cdr_coat_validation_20261020_yahoo_integration.json):
  chỉ validation, không chấm held-out test, không tuning.
- [CDR source Coat](cdr_source_coat_20261020_222318_c9e8d6e9.json): chạy đủ điều kiện
  script, NDCG .656665 / Recall bounded .667816 / AUC toàn cục .751293.
  Dùng 5% nhãn random chấm điểm cho propensity; không phải held-out benchmark.
- [CDR source Yahoo 1 epoch](cdr_source_yahoo_20261020_222146_a4c6d011.json):
  chỉ kiểm tra vận hành source-protocol; chưa chạy đủ ngân sách.

Các artifact phát triển `benchmark_yahoo_all_quick_4d1d116062...` và
`cdr_source_coat_20261020_222002...` giữ nguyên source hash của chúng; không thay
cho biên bản kiểm chứng source cuối. Chưa có benchmark chất lượng đầy đủ của
ba mô hình Yahoo ở mốc này. Yahoo iDCF là mở rộng địa phương, có thiếu survey;
không gắn số với paper iDCF.

## Benchmark Coat trước tích hợp released và audit CDR

[Báo cáo người dùng vừa chạy](benchmark_coat_all_16747d3add_20261020_194738_4bb0b674_v4.md)
· [JSON](benchmark_coat_all_16747d3add_20261020_194738_4bb0b674_v4.json):
full-data seed 42, source `d5bdd13e82c3`, Test NDCG MF .547612, iDCF .569884,
CDR Eq. (7) .448514. Không dùng validation hoặc diagnostic thay cho bảng này;
không chuyển điểm CDR này sang bản released hiện hành.

[Lượt chạy lại 20:13](benchmark_coat_all_16747d3add_20261020_201340_ff77c17a_v4.json)
· [MD](benchmark_coat_all_16747d3add_20261020_201340_ff77c17a_v4.md) có cùng source,
cấu hình, seed và điểm với lượt 19:48; không coi là seed độc lập.

[Audit CDR sau benchmark](cdr_followup_audit_20261020.json) giữ kiểm tra dữ liệu,
checkpoint, validation controls và đối chứng script công bố. Script diagnostic
đạt .656665 NDCG / .667816 Recall bounded, có dùng 5% nhãn random chấm điểm cho
propensity; **không phải held-out benchmark dự án**. Giữ nguyên checkpoint đó
chấm >=4/test pool dự án còn .479693, vẫn chỉ là diagnostic.
[Phân tích](../docs/benchmarks/root_cause_analysis.md) nêu khác biệt paper/source.

## Validation sau sửa pipeline Coat

[Validation ba seed](coat_pipeline_fix_validation_20261020.json): CDR và iDCF
huấn luyện đầy đủ trên train, không gọi held-out test; MF seed 42 làm đối chứng.
CDR đã chọn cấu hình qua một phần miền tuning paper và ba seed validation;
mean/std ở đây là mô tả quá trình chọn cấu hình, không phải benchmark độc lập.
[Search evidence](coat_pipeline_fix_search_20261020.json) giữ cấu hình và source
của từng trial phát triển; không đổi chúng sang source của bản chốt.

[CLI smoke Coat sau sửa — JSON](benchmark_coat_all_quick_13e80854d6_20261020_192736_117c64b0_v4.json)
· [Markdown](benchmark_coat_all_quick_13e80854d6_20261020_192736_117c64b0_v4.md):
cả ba mô hình chạy được ở source `d5bdd13e82c3`, feedback 1 epoch / iVAE 2 epoch;
chỉ xác nhận vận hành, không dùng điểm lượt này so với benchmark đầy đủ hoặc paper.

## Benchmark đầy đủ trước sửa pipeline Coat

[Coat, seed 42 — báo cáo](coat_full_20261020_185436_60df72/benchmark_coat_all_429e263db0_v4.md)
· [JSON](coat_full_20261020_185436_60df72/benchmark_coat_all_429e263db0_v4.json)
· [yêu cầu/cấu hình chạy](coat_full_20261020_185436_60df72/request.json)
· [biên bản hoàn tất](coat_full_20261020_185436_60df72/completion.json).
MF/iDCF/CDR chạy đầy đủ dữ liệu, cấu hình mặc định và early stopping; source
`36230d1cd908`, data `314c797e7674`. Chưa tuning, một seed, không phải tái lập paper.
IViDR-approx không thuộc lượt này. Log, script chạy và checkpoint riêng được giữ để đối chiếu.

Lượt người dùng chạy lại: [báo cáo](benchmark_coat_all_429e263db0_v4.md) ·
[JSON](benchmark_coat_all_429e263db0_v4.json). Cùng điểm, source/data và seed với
lượt trong thư mục riêng; không coi là seed độc lập hoặc bằng chứng độ ổn định.
[Phân tích báo cáo](coat_report_analysis_20261020.json) chỉ đọc metadata, lịch sử,
trọng số propensity của train và kiến trúc checkpoint công khai của tác giả;
không có retraining, tuning hoặc lần chấm test mới. Kết luận và giới hạn nằm ở
[root cause analysis](../docs/benchmarks/root_cause_analysis.md).

## Validation, chẩn đoán và kết quả lịch sử

| Artifact | Phạm vi sử dụng | Nguồn ghi trong JSON |
| :-- | :-- | :-- |
| [benchmark_all_8c15e5d925_v4.json](benchmark_all_8c15e5d925_v4.json) · [MD](benchmark_all_8c15e5d925_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | `a9fdeb72ccd6` — source lịch sử |
| [benchmark_coat_all_003679088f_v4.json](benchmark_coat_all_003679088f_v4.json) · [MD](benchmark_coat_all_003679088f_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | 2 source hash khác mốc hiện hành; kiểm tra từng metadata |
| [benchmark_coat_all_19d70ea039_v4.json](benchmark_coat_all_19d70ea039_v4.json) · [MD](benchmark_coat_all_19d70ea039_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | `22ea114a3bdb` — source lịch sử |
| [benchmark_coat_ividr_9cf02b470b_v4.json](benchmark_coat_ividr_9cf02b470b_v4.json) · [MD](benchmark_coat_ividr_9cf02b470b_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | `946754273f79` — source lịch sử |
| [benchmark_kuairand_all_2edb44f179_v4.json](benchmark_kuairand_all_2edb44f179_v4.json) · [MD](benchmark_kuairand_all_2edb44f179_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | 3 source hash khác mốc hiện hành; kiểm tra từng metadata |
| [benchmark_kuairand_all_32e6ded9ad_v4.json](benchmark_kuairand_all_32e6ded9ad_v4.json) · [MD](benchmark_kuairand_all_32e6ded9ad_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | 2 source hash khác mốc hiện hành; kiểm tra từng metadata |
| [cdr_author_protocol_coat_thr3.json](cdr_author_protocol_coat_thr3.json) | Port chẩn đoán; dùng một phần nhãn tập chấm điểm cho propensity; thiếu source hash; không xác nhận tái lập paper | Không có source hash; chưa đủ provenance |
| [cdr_eq7_validation_6346597634257fd0.json](cdr_eq7_validation_6346597634257fd0.json) | Warm-start ablation đã bị thay thế; ba seed chọn MF epoch 0; không đại diện CDR độc lập | `999931b4f5cc` — source lịch sử |
| [cdr_idcf_tune_coat.json](cdr_idcf_tune_coat.json) | Port/filter variance, tuning theo giao thức dự án; thiếu source hash; không thuộc cấu hình CDR hiện hành | Không có source hash; chưa đủ provenance |
| [cdr_paper_method_validation_37b126f2c13fcea9.json](cdr_paper_method_validation_37b126f2c13fcea9.json) | CDR độc lập trước sửa pipeline, ba seed; chỉ validation; có ghi riêng smoke hai dataset; chưa tuning/test | `36230d1cd908` — source trước sửa |
| [coat_seeds_7ae4942b7c4a9f32.json](coat_seeds_7ae4942b7c4a9f32.json) · [MD](coat_seeds_7ae4942b7c4a9f32.md) | CDR lịch sử trước cơ chế giữ epoch 0; không đại diện CDR huấn luyện độc lập | `e5106d9db885` — source lịch sử |
| [coat_seeds_7d37e1975c96a410.json](coat_seeds_7d37e1975c96a410.json) · [MD](coat_seeds_7d37e1975c96a410.md) | iDCF và IViDR-staged cũ; IViDR dùng alpha_residual=1; không phải bản đúng paper | `02582b7e7987` — source lịch sử |
| [coat_seeds_c25da453e8909e5b.json](coat_seeds_c25da453e8909e5b.json) · [MD](coat_seeds_c25da453e8909e5b.md) | Bộ nhiều seed cũ; có kiến trúc joint/CDR cũ; không gán lại số cho mô hình hiện hành | `fbe2d03c1f3d` — source lịch sử |
| [tuning_kuairand_all_e25_4deb0568781e5d74_v4.json](tuning_kuairand_all_e25_4deb0568781e5d74_v4.json) · [MD](tuning_kuairand_all_e25_4deb0568781e5d74_v4.md) | Kết quả benchmark/tuning lịch sử; đọc metadata từng model/checkpoint; không đại diện mốc source hiện hành | `22ea114a3bdb` — source lịch sử |

## Quy tắc trích kết quả

- Trích JSON gốc kèm dataset, mô hình/biến thể, loss, source/data hash, seed và protocol.
- Nếu một artifact có nhiều source hash, không gọi toàn bộ là một phiên bản source đồng nhất.
- Không dùng validation hoặc smoke thay held-out test; không dùng test nhiều lần để chọn cấu hình.
- Markdown cũ có thể kèm bảng paper hoặc kết luận lỗi thời. Giữ nguyên để đối chiếu, không coi phần diễn giải đó là kết luận hiện tại.
- Với port thiếu source hash, không suy mã đã chạy từ file source đang có hôm nay.
- Lượt chạy mới phải đăng ký riêng trong catalog; không đổi nhãn hay ghi đè artifact cũ.
