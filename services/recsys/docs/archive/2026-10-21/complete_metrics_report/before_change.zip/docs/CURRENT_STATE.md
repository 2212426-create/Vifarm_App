# Trạng thái RecSys hiện hành

Mốc **20/10/2026: đồng nhất log MF/iDCF/CDR, giữ CDR source protocol mặc định**.
[Snapshot](state_snapshot.json) · [Lệnh chạy](../README.md) ·
[Định nghĩa](benchmarks/paper_model_alignment.md) · [Giao thức](benchmarks/evaluation_protocol.md).

Source đã kiểm chứng:
`134b536cc623a5b925adc8b2e4b8fcb2d8880ff54ccfd0b4002b294b5c532154`.

Log dùng chung tiêu đề cấu hình, prefix model/dataset, tiến độ epoch, kết thúc
và checkpoint. iDCF hiển thị cả iVAE (train/val ELBO, beta, warm-up/full-beta)
và feedback (train loss, validation ranking). CDR source ghi rec/imp loss từng
epoch rồi SOURCE EVAL cuối lượt; không tự thêm validation hoặc đổi cơ chế dừng.
Không thay đổi loss, seed, split, metric, optimizer hay lựa chọn checkpoint.

## Mặc định đang chạy

- CDR benchmark Coat/Yahoo dùng cùng hàm `run_source` với `cdr-source`:
  seed 2020, dim 4, trần 1000 epoch, dừng theo train loss và lấy trọng số cuối.
  Nhãn >=3; calibration bằng 5% nhãn random chấm điểm; đánh giá toàn random log,
  zero-positive nhận 1, Recall bounded và AUC toàn cục.
- Lệnh `benchmark --dataset coat --model cdr` đã chạy đầy đủ:
  **NDCG .6566651228 / Recall bounded .6678160920 / AUC .7512927651**.
  [Báo cáo sau đổi log](../results/benchmark_coat_cdr_dd41848bc6_20261020_231233_64456c33_v4.md).
  Khớp lượt cdr-source người dùng xác nhận; không gọi đây là test độc lập chưa dùng nhãn calibration.
  [Yahoo source đầy đủ trước đổi log, source abc819e34351](../results/cdr_source_yahoo_20261020_225246_193982ea.json):
  NDCG .655929 / Recall bounded .731299 / AUC global .684930; không gán lại số paper.
- MF/iDCF giữ MSE, >=4, random-log user split 30/70 và checkpoint validation.
  Báo cáo CDR source ở bảng riêng; không kiểm định chéo với MF/iDCF trên hai protocol khác nhau.
- KuaiRand đã chuyển sang thuật toán CDR released. Dữ liệu vẫn là preprocessing
  địa phương; calibration 5% validation; array sampling thay DataLoader; catalog
  lớn dùng sampling có hoàn lại để giới hạn RAM. Không tuyên bố tái lập chính xác script KuaiRand.
- API đã dùng ReleasedCDR 4 chiều, variance filter, output dropout và source
  update/loss. App không có random log nên giữ propensity item-frequency và
  sampling có hoàn lại, ghi trong training_stats.cdr. Ngân sách phục vụ riêng.
- Tuning Coat/KuaiRand dùng estimator released, trần 1000, seed 2020,
  train-loss stopping/lấy trọng số cuối, calibration 5% validation. Chọn cấu hình
  bằng validation; không dùng nhãn test để tune. Đây là tuning adaptation,
  không phải cách lấy điểm source protocol. Coat CDR tuning dùng >=3, MF >=4.
- `coat-seeds` dùng source protocol cho CDR; checkpoint được giữ lại.
  Recall được gắn đúng tên bounded, không Wilcoxon chéo protocol.
- `cdr-author` là alias `cdr-source`; `cdr-tune` alias tuning released.
  Bản Eq. (7) cũ chỉ chạy tường minh qua `--cdr-implementation equation` hoặc
  hàm legacy; giữ để đọc checkpoint/ablation. `--cdr-implementation shared`
  dùng released với giao thức held-out chung.

## Kiểm chứng

**115 test: 114 đạt, 1 CUDA bỏ qua**.
[Log](archive/2026-10-20/unified_training_logs/model_tests.log).
Có kiểm thử 3 epoch CPU khớp từng trọng số lớp gốc, metric source, loại CDR
source khỏi paired tests chung, sampler cho event lặp, API released và dispatch tuning.
Hai test mới xác nhận progress callback không đổi tham số/history/dừng sớm CDR,
latent và checkpoint selection của iVAE.

[Biên bản mốc log](../results/unified_training_logs_verification_20261020.json)
dẫn smoke ba mô hình Coat, CDR Coat source đầy đủ và hồi quy validation ba seed.
[Biên bản trước đổi log](../results/cdr_source_default_verification_20261020.json)
giữ kiểm chứng ba dataset, chạy seed, tuning, API và reload tại source abc819e34351.
[Validation-only diagnostic sau đổi log](../results/unified_training_logs_validation_20261020.json)
là phép kiểm tra riêng của estimator với validation, không thay điểm source benchmark.
Ba seed khớp chính xác epoch/điểm validation của mốc trước.
Không coi smoke/quick là kết quả chất lượng.

Python 3.12.10, PyTorch 2.14.1+cpu, NumPy 2.5.4, pandas 3.0.6; CPU 2 thread.
Chưa kiểm chứng CUDA.

## Yahoo và các giới hạn giữ nguyên

Yahoo! R3: 15.400 user, 1.000 item; 311.704 train / 54.000 random ratings;
đã tải từ commit nguồn được chỉ định. MF/iDCF chuyển ID về 0-based; CDR source
giữ ID 1-based/dummy row như script. Train/random overlap bằng 0.

iDCF Yahoo dùng 7 câu survey thật, one-hot 39 chiều; 10.000 user thiếu survey
nhận category thiếu. Đây là mở rộng địa phương, chưa phải kết quả Yahoo của paper
iDCF; giả định nhân quả ở nhóm thiếu survey chưa được xác minh.
iVAE Coat/Yahoo 16/32/3, KuaiRand 32/64/2, chọn sau full-beta warm-up.
IViDR vẫn là bản xấp xỉ và không thuộc bộ mặc định.

## Lịch sử

Source trước `88769819bd67` dùng released nhưng calibration/chọn checkpoint theo
giao thức chung; chưa phải mặc định source protocol hiện nay.
[Kiểm chứng cũ](../results/yahoo_source_integration_verification_20261020.json)
giữ nguyên số và hash. CDR Eq. (7) .448514 tại source `d5bdd13e82c3` không phải
điểm của CDR source hiện hành.
[Bản trước thay đổi](archive/2026-10-20/cdr_source_default/before_change.zip).

[Catalog kết quả](../results/CATALOG.md) · [Bảo toàn tài liệu](MAINTENANCE.md).
