# RecSys: đọc trạng thái trước khi sửa hoặc đánh giá mô hình

Phạm vi: toàn bộ `services/recsys/`.

1. Đọc `docs/CURRENT_STATE.md` trước, sau đó `docs/benchmarks/paper_model_alignment.md`
   và `docs/benchmarks/evaluation_protocol.md` nếu tác vụ liên quan mô hình/metric.
2. Trạng thái hiện tại phải được đối chiếu với logic thực thi và config, không suy ra
   từ comment, tên `v4`, thời gian sửa file, slide hoặc bảng điểm cũ.
3. Đọc `results/CATALOG.md` và metadata JSON trước khi trích số. Phân biệt test,
   validation, smoke, ablation và số paper. Không dùng các số này thay thế cho nhau.
4. `training_profile=paper` là tên profile của triển khai CDR theo công thức;
   không có nghĩa đã tái lập đầy đủ thí nghiệm paper. IViDR hiện là bản xấp xỉ,
   bị loại khỏi bộ chạy mặc định. Không đưa lại chỉ vì một kết quả cũ cao hơn.
   Người dùng đã chọn CDR source protocol làm mặc định: Coat/Yahoo >=3,
   calibration 5% nhãn random chấm điểm, toàn random log, train-loss stopping,
   Recall bounded/AUC global. Không tự đổi mặc định này thành shared validation-only.
   Báo cáo riêng protocol và không paired-test với MF/iDCF khác giao thức.
5. Không ghi đè artifact kết quả, evidence, PDF/bản chép paper hoặc snapshot lưu trữ.
   Khi sửa một nhận định lịch sử, ghi đính chính ở tài liệu hiện hành, dẫn file gốc;
   chạy lại thí nghiệm phải tạo artifact mới có nguồn/cấu hình rõ ràng.
6. Khi code/config/protocol thay đổi, cập nhật trạng thái và bằng chứng phù hợp.
   Không đổi source hash của một lượt chạy cũ thành hash mới và không chuyển điểm
   lịch sử sang phiên bản mới. `docs/state_snapshot.json` ghi mốc kiểm chứng cụ thể.
7. Chạy `python docs/check_docs.py` sau chỉnh tài liệu. Nếu source hash khác snapshot,
   rà lại thay đổi và ghi mốc mới sau kiểm chứng; không bỏ qua bằng cách gán lại hash cũ.
   Tài liệu mới cần được phân loại trong `docs/catalog.json`.

Các quy tắc này giữ thông tin có thể đối chiếu qua các lần làm việc; không yêu cầu
xin phép cho thao tác rà soát hay sửa lỗi đã được người dùng giao.
