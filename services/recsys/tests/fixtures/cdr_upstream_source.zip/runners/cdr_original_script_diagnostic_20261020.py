"""Literal released Coat experiment diagnostic; deliberately NOT held-out evaluation."""
import ast,json,pathlib,sys,tempfile,time,contextlib,hashlib
from collections import defaultdict
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
sys.path.insert(0,str(pathlib.Path.cwd()))
from src.data_pipeline.coat_dataset import load_coat_raw_features,load_coat_processed

torch.set_num_threads(2)
folder=pathlib.Path(tempfile.gettempdir())/'cdr_original_source_audit_20261020'
ns={'np':np,'torch':torch,'nn':nn,'F':F,'defaultdict':defaultdict}
for file,wanted in [('utils.py',{'McDropout','binarize','rating_mat_to_sample','ndcg_func','recall_func'}),
        ('MF_mcdropout.py',{'generate_total_sample','MF_BaseModel','MF_McdropoutModel','MF_DR_BIAS_MCDROPOUT'})]:
    tree=ast.parse((folder/file).read_text('utf-8'))
    selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in wanted]
    assert {n.name for n in selected}==wanted
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(folder/file),'exec'),ns)

np.random.seed(2020);torch.manual_seed(2020)
raw=load_coat_raw_features()
xtr,ytr=ns['rating_mat_to_sample'](raw['train_matrix'])
xte,yte=ns['rating_mat_to_sample'](raw['test_matrix'])
ytr=ns['binarize'](ytr);yte=ns['binarize'](yte)
m=ns['MF_DR_BIAS_MCDROPOUT'](290,300)
idx=np.arange(len(yte));np.random.shuffle(idx)
ips_idx=idx[:int(.05*len(idx))]
start=time.perf_counter()
with (folder/'released_script_diagnostic.log').open('w',encoding='utf-8') as f,contextlib.redirect_stdout(f):
    m.fit(xtr,ytr,y_ips=yte[ips_idx],lr=.05,batch_size=128,lamb=.001,tol=1e-5,G=4,verbose=False)
ndcg=ns['ndcg_func'](m,xte,yte)
recall=ns['recall_func'](m,xte,yte)
result={'scope':'Literal released script training/label/calibration/metric diagnostic; NOT independent held-out benchmark',
    'original_source':json.loads((folder/'manifest.json').read_text('utf-8')),
    'runner_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    'conditions':dict(seed=2020,label='rating>=3',calibration='5% of entire random evaluation log, as in released script',
        calibration_rows=len(ips_idx),test_labels_used_for_propensity=True,evaluation='entire random log, 290 users',
        zero_positive_ndcg=1,recall_denominator='min(k,number_of_positive_items)',lr=.05,batch_size=128,wd=.001,filter='variance',threshold=10,output_probability_dropout=True),
    'ndcg5':float(np.mean(ndcg['ndcg_5'])),'recall5_bounded':float(np.mean(recall['recall_5'])),
    'training_end_log':(folder/'released_script_diagnostic.log').read_text('utf-8'),
    'elapsed_seconds':time.perf_counter()-start,
    'limits':['Do not use this score as project held-out test result','Source environment differs from paper Python3.7/PyTorch1.9; no hyperparameter selection from this run','This experiment uses labels that the project reserves for test and is only a source-protocol diagnostic']}
(folder/'released_script_diagnostic.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
torch.save(m.state_dict(),folder/'released_script_diagnostic_weights.pt')
print(json.dumps(result,indent=2))
