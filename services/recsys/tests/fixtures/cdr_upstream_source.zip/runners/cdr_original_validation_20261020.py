import ast,json,pathlib,sys,tempfile,time,contextlib,hashlib
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
sys.path.insert(0,str(pathlib.Path.cwd()))
from src.data_pipeline.coat_dataset import load_coat_processed
from src.causal.cdr.propensity import validation_labels
from src.evaluation.evaluator import evaluate_unbiased_model
from src.utils.artifacts import data_signature

torch.set_num_threads(2)
folder=pathlib.Path(tempfile.gettempdir())/'cdr_original_source_audit_20261020'
provenance=json.loads((folder/'manifest.json').read_text('utf-8'))
ns={'np':np,'torch':torch,'nn':nn,'F':F}
for name,wanted in [('utils.py',{'McDropout'}),('MF_mcdropout.py',{'generate_total_sample','MF_BaseModel','MF_McdropoutModel','MF_DR_BIAS_MCDROPOUT'})]:
    tree=ast.parse((folder/name).read_text('utf-8'))
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in wanted]
    assert {n.name for n in nodes}==wanted
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(folder/name),'exec'),ns)

data=load_coat_processed()
np.random.seed(42);torch.manual_seed(42)
m=ns['MF_DR_BIAS_MCDROPOUT'](290,300)
start=time.perf_counter()
with (folder/'original_class_validation.log').open('w',encoding='utf-8') as f,contextlib.redirect_stdout(f):
    m.fit(np.stack([data['train_u'],data['train_i']],1),data['train_y'],
          y_ips=validation_labels(data),lr=.05,batch_size=128,lamb=.001,tol=1e-5,G=4,verbose=False)

class FactorWrapper(nn.Module):
    def __init__(self,source): super().__init__();self.source=source
    def get_evaluation_factors(self):
        return (self.source.prediction_model.W.weight.detach().numpy(),
                self.source.prediction_model.H.weight.detach().numpy())

metrics=evaluate_unbiased_model(FactorWrapper(m),data['val_candidates'],data['val_ground_truth'],include_zero_positive_users=False)
result={'scope':'Diagnostic: exact released class definitions and fit, on project rating>=4 train and validation-only calibration; validation scoring only',
        'original_source':provenance,'runner_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        'changes_from_released_script':['Labels >=4 and project 30/70 user split, not script >=3 and full random test',
            'All 1392 random validation labels for NB calibration, never held-out test labels','Seed 42 instead of 2020',
            'Same local validation evaluator instead of source ndcg_func; training loop unchanged'],
        'config':dict(seed=42,lr=.05,batch_size=128,weight_decay=.001,num_epoch=1000,un_thres=10,filter='variance',G=4,Nsamples=10),
        'data':data_signature(data),'validation':metrics,'elapsed_seconds':time.perf_counter()-start,
        'training_end_log':(folder/'original_class_validation.log').read_text('utf-8'),
        'not_paper_reproduction':True}
torch.save(m.state_dict(),folder/'original_class_validation_weights.pt')
(folder/'original_class_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
