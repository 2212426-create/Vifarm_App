import json, pathlib, sys, tempfile, hashlib
import numpy as np
import torch
import torch.nn.functional as F
sys.path.insert(0, str(pathlib.Path.cwd()))
from src.causal.cdr.cdr_model import CDRFramework
from src.causal.cdr.dr_bias_loss import imputed_bce, imputation_keep
from src.data_pipeline.coat_dataset import load_coat_processed, load_coat_raw_features
from src.utils.artifacts import load_checkpoint

torch.set_num_threads(2)
root = pathlib.Path.cwd()
report_path = root/'results/benchmark_coat_all_16747d3add_20261020_194738_4bb0b674_v4.json'
report = json.loads(report_path.read_text('utf-8'))
data, raw = load_coat_processed(), load_coat_raw_features()
checkpoint = pathlib.Path(report['coat']['DR-BIAS + CDR']['checkpoint_path'])
state = load_checkpoint(checkpoint)
model = CDRFramework(**state['metadata']['model_kwargs']).eval()
model.load_state_dict(state['model_state_dict'])
out = dict(report=str(report_path), checkpoint=str(checkpoint),
           checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
           source_sha256=state['metadata']['code_sha256'], diagnostics={}, rescoring=[])

with torch.no_grad():
    for split in ['train', 'val']:
        if split == 'train':
            us, items, ys = data['train_u'], data['train_i'], data['train_y']
        else:
            pairs = [(u, i) for u, candidates in data['val_candidates'].items() for i in candidates]
            us, items = np.array(pairs).T
            ys = np.array([float(i in data['val_ground_truth'][u]) for u, i in pairs])
        u, i, y = torch.as_tensor(us).long(), torch.as_tensor(items).long(), torch.as_tensor(ys).float()
        logits = model(u, i)
        q = model.imp_model(u, i).sigmoid()
        torch.manual_seed(1234)
        qs = model.imp_model.sample_predict(u, i, num_samples=200)
        mean, variance = model.imp_model.sample_bce(logits, qs, from_logits=True)
        true_error = F.binary_cross_entropy_with_logits(logits, y, reduction='none')
        deterministic_error = imputed_bce(logits, q)
        keep = imputation_keep(mean, variance, .1).bool()
        poisonous = (mean - true_error).abs() > true_error
        out['diagnostics'][split] = dict(
            rows=len(y), positive_rate=float(y.mean()),
            rec_probability_quantiles=torch.quantile(logits.sigmoid(), torch.tensor([.01,.1,.5,.9,.99])).tolist(),
            deterministic_q_bce=float(F.binary_cross_entropy(q,y)),
            mc_mean_q_bce=float(F.binary_cross_entropy(qs.mean(0),y)),
            q_mc_vs_deterministic_mean_abs_difference=float((qs.mean(0)-q).abs().mean()),
            deterministic_imputation_mse=float((deterministic_error-true_error).square().mean()),
            mc_imputation_mse=float((mean-true_error).square().mean()),
            filter_removed_fraction=float((~keep).float().mean()),
            poisonous_fraction=float(poisonous.float().mean()),
            poisonous_retained_fraction=float(poisonous[keep].float().mean()) if keep.any() else None,
            poisonous_removed_fraction=float(poisonous[~keep].float().mean()) if (~keep).any() else None)

    # Descriptive re-scoring of ONE fixed checkpoint, never used to select weights.
    # This changes only label/aggregation rules, not training or model weights.
    for threshold, users, empty_one in [(4,list(data['test_candidates']),False),
            (3,list(data['test_candidates']),False),(4,list(range(290)),True),
            (3,list(range(290)),False),(3,list(range(290)),True)]:
        scores, positives, skipped = [], 0, 0
        for user in users:
            candidates = np.flatnonzero(raw['test_matrix'][user] > 0)
            truth = raw['test_matrix'][user,candidates] >= threshold
            positives += int(truth.sum())
            if not truth.any():
                skipped += 1
                if empty_one: scores.append(1.)
                continue
            pred = model(torch.full((len(candidates),),user),torch.as_tensor(candidates)).numpy()
            order = np.lexsort((candidates,-pred))[:5]
            discount = 1/np.log2(np.arange(2,7))
            scores.append(float((truth[order]*discount[:len(order)]).sum()/discount[:min(5,int(truth.sum()))].sum()))
        out['rescoring'].append(dict(threshold=threshold, pool='project_test' if len(users)==203 else 'all_random',
            zero_positive='one' if empty_one else 'exclude', ndcg5=float(np.mean(scores)),
            scored_users=len(scores), zero_positive_users=skipped,positive_rows=positives))

dest = pathlib.Path(tempfile.gettempdir())/'cdr_original_source_audit_20261020/checkpoint_probe.json'
dest.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
