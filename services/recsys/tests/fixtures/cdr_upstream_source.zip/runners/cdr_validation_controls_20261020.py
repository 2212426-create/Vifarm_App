import pathlib,sys,tempfile,contextlib,json,time,copy,hashlib
from unittest.mock import patch
import numpy as np
import torch
import torch.nn.functional as F
sys.path.insert(0,str(pathlib.Path.cwd()))
from src.causal.cdr.cdr_model import CDRFramework
from src.causal.cdr.dr_bias_loss import dr_bias_closed_form_imputation_loss
from src.causal.cdr.train_dr_bias_cdr import train_dr_bias_cdr
from src.causal.cdr.propensity import naive_bayes_propensity,validation_labels
from src.data_pipeline.coat_dataset import load_coat_processed
from src.training.config import cdr_config
from src.models.matrix_factorization import MatrixFactorization
from src.evaluation.evaluator import evaluate_unbiased_model
from src.utils.helpers import set_seed
from src.utils.artifacts import source_signature

torch.set_num_threads(2)
data=load_coat_processed()
out=pathlib.Path(tempfile.mkdtemp(prefix='cdr_validation_controls_'))
print('OUT',out,flush=True)
result={'scope':'validation-only controls; source unmodified; dynamic diagnostic overrides explicitly identified',
    'source_sha256':source_signature(),'runner_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'controls':[]}
u=torch.as_tensor(data['train_u']).long();i=torch.as_tensor(data['train_i']).long();y=torch.as_tensor(data['train_y'])
w,_=naive_bayes_propensity(data['train_y'],validation_labels(data),.08)

# Plain MF dot-product control with the exact CDR recommendation backbone/budget.
set_seed(42)
m=MatrixFactorization(290,300,embedding_dim=4,use_bias=False,init_scheme='xavier_normal')
opt=torch.optim.Adam(m.parameters(),lr=.1,weight_decay=.0001)
best=-1.;best_epoch=0
for epoch in range(1,101):
    m.train()
    for idx in np.array_split(np.random.permutation(len(y)),int(np.ceil(len(y)/512))):
        loss=F.binary_cross_entropy_with_logits(m(u[idx],i[idx]),y[idx])
        opt.zero_grad();loss.backward();opt.step()
    m.eval();val=evaluate_unbiased_model(m,data['val_candidates'],data['val_ground_truth'],include_zero_positive_users=False)['NDCG@5']
    if val>best: best,best_epoch=val,epoch
    elif epoch-best_epoch>=20: break
result['controls'].append(dict(name='CDR_backbone_plain_BCE_no_debiasing',val_ndcg=best,best_epoch=best_epoch,epochs_run=epoch,
    config=dict(dim=4,use_bias=False,init='xavier_normal',lr=.1,wd=.0001,batch_size=512,patience=20)))
print(result['controls'][-1],flush=True)

def released_reverse_bce(self,u,i,y,w):
    with torch.no_grad():
        logits=self.rec_model(u,i)
        p=logits.sigmoid()
        e=F.binary_cross_entropy_with_logits(logits,y,reduction='none')
    qlogits=self.imp_model(u,i)
    h=F.binary_cross_entropy_with_logits(qlogits,p,reduction='none')
    return dr_bias_closed_form_imputation_loss(e,h,w)

# One-factor diagnostic: only released imputation BCE argument direction.
# This is NOT the unchanged paper-formulation profile, despite base metadata.
for eta in [.1,10.]:
    cfg=cdr_config('coat',un_thres=eta)
    with patch.object(CDRFramework,'compute_imputation_loss',released_reverse_bce), \
            (out/f'reverse_eta_{eta}.log').open('w',encoding='utf-8') as f,contextlib.redirect_stdout(f):
        t=train_dr_bias_cdr('coat',data_dict=data,checkpoint_dir=str(out/f'reverse_eta_{eta}'),
            evaluate_test=False,device='cpu',**cfg)
    result['controls'].append(dict(name='diagnostic_released_reverse_BCE_only',runtime_override='CDRFramework.compute_imputation_loss = released_reverse_bce in this runner',
        not_paper_reproduction=True,eta=eta,result=t))
    print('REVERSE',eta,t['best_val_ndcg'],t['best_epoch'],flush=True)
    (out/'controls.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
assert source_signature()==result['source_sha256']
print('COMPLETE',flush=True)
